// Package web — WebAgent (tiếp theo)
// Dùng Claude để extract knowledge từ plain text → KNode

package web

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"net/http"
	"strings"
	"time"
)

// Extractor — dùng Claude extract knowledge
type Extractor struct {
	APIKey string
	Store  *NodeStore
}

func NewExtractor(apiKey string, store *NodeStore) *Extractor {
	return &Extractor{APIKey: apiKey, Store: store}
}

// LearnURL — pipeline đầy đủ: fetch → extract → ghi ○
func (e *Extractor) LearnURL(rawURL string) (*KNode, error) {
	// 1. Fetch
	result, err := Fetch(rawURL)
	if err != nil {
		return nil, fmt.Errorf("learn: fetch: %w", err)
	}

	// 2. Extract knowledge
	node, err := e.extract(result)
	if err != nil {
		return nil, fmt.Errorf("learn: extract: %w", err)
	}

	// 3. Ghi vào WORLDTREE
	if err := e.Store.Write(node); err != nil {
		return nil, fmt.Errorf("learn: write: %w", err)
	}

	return node, nil
}

// extract — gửi plain text đến Claude → nhận KNode
func (e *Extractor) extract(f *FetchResult) (*KNode, error) {
	if e.APIKey == "" {
		return e.extractFallback(f), nil
	}

	prompt := fmt.Sprintf(`Đọc nội dung sau và trích xuất knowledge để lưu vào WORLDTREE của HomeOS.

URL: %s
Tiêu đề: %s

NỘI DUNG (plain text):
---
%s
---

Trả về JSON (không markdown):
{
  "name": "tên khái niệm chính (1-3 từ tiếng Anh, lowercase)",
  "symbol": "2-4 emoji/ký hiệu Unicode tóm tắt khái niệm",
  "summary": "1-2 câu tóm tắt ngắn gọn bằng tiếng Việt",
  "facts": [
    {"sym": "ký hiệu ○-lang", "text": "fact ngắn tiếng Việt"},
    ...tối đa 8 facts quan trọng nhất
  ],
  "tags": ["tag1", "tag2", ...tối đa 6 tags],
  "related": ["khái niệm liên quan 1", "khái niệm liên quan 2", ...tối đa 5],
  "sdf": [x, y, z],
  "isl_layer": "L|N|S|M|P",
  "confidence": 0.0-1.0
}

Về SDF [x, y, z] — vị trí trong không gian tri thức (-1.0 đến 1.0):
  x: -1=cổ đại/lịch sử, 0=trung lập, +1=hiện đại/kỹ thuật
  y: -1=ký hiệu/toán, 0=trung lập, +1=ngôn ngữ/văn bản
  z: -1=CJK/châu Á, 0=trung lập, +1=Latin/phương Tây/emoji

Về ISL layer:
  L = ngôn ngữ/text, N = số, S = ký hiệu/emoji, M = toán, P = dấu câu

Về symbol: dùng emoji thật, không dùng text. Ví dụ: 🌱☀→🍬 cho photosynthesis`,
		f.URL, f.Title,
		truncateWords(f.PlainText, 3000))

	raw, err := e.callClaude(prompt)
	if err != nil {
		return e.extractFallback(f), nil
	}

	// parse JSON
	raw = strings.TrimSpace(raw)
	raw = strings.TrimPrefix(raw, "```json")
	raw = strings.TrimPrefix(raw, "```")
	raw = strings.TrimSuffix(raw, "```")
	raw = strings.TrimSpace(raw)

	var parsed struct {
		Name       string    `json:"name"`
		Symbol     string    `json:"symbol"`
		Summary    string    `json:"summary"`
		Facts      []Fact    `json:"facts"`
		Tags       []string  `json:"tags"`
		Related    []string  `json:"related"`
		SDF        [3]float64 `json:"sdf"`
		ISLLayer   string    `json:"isl_layer"`
		Confidence float64   `json:"confidence"`
	}
	if err := json.Unmarshal([]byte(raw), &parsed); err != nil {
		return e.extractFallback(f), nil
	}

	// build ISL từ layer
	isl := layerToISL(parsed.ISLLayer, f.URL)

	node := &KNode{
		ID:         f.Hash,
		Name:       parsed.Name,
		Title:      f.Title,
		URL:        f.URL,
		LearnedAt:  time.Now(),
		Symbol:     parsed.Symbol,
		ISL:        isl,
		SDF:        normalizeSDF(parsed.SDF),
		Summary:    parsed.Summary,
		Facts:      parsed.Facts,
		Tags:       parsed.Tags,
		Related:    parsed.Related,
		Confidence: parsed.Confidence,
		Source:     "web",
	}
	return node, nil
}

// extractFallback — không có API key, extract tối giản từ text
func (e *Extractor) extractFallback(f *FetchResult) *KNode {
	// lấy 2 câu đầu làm summary
	sentences := strings.SplitN(f.PlainText, ".", 4)
	summary := ""
	for i, s := range sentences {
		if i >= 2 { break }
		summary += strings.TrimSpace(s) + ". "
	}
	if len(summary) > 200 { summary = summary[:200] + "…" }

	// tags từ title words
	tags := strings.Fields(strings.ToLower(f.Title))
	if len(tags) > 5 { tags = tags[:5] }

	return &KNode{
		ID:         f.Hash,
		Name:       slugify(f.Title),
		Title:      f.Title,
		URL:        f.URL,
		LearnedAt:  time.Now(),
		Symbol:     "📄",
		ISL:        [4]byte{0x01, 0x01, 0x00, 0x01},
		SDF:        [3]float64{0, 0, 0},
		Summary:    summary,
		Facts:      []Fact{{Symbol: "📄", Text: summary}},
		Tags:       tags,
		Confidence: 0.5,
		Source:     "web-fallback",
	}
}

// callClaude — gọi Claude API
func (e *Extractor) callClaude(prompt string) (string, error) {
	body, _ := json.Marshal(map[string]any{
		"model":      "claude-sonnet-4-20250514",
		"max_tokens": 1200,
		"messages": []map[string]string{
			{"role": "user", "content": prompt},
		},
	})

	req, err := http.NewRequest("POST",
		"https://api.anthropic.com/v1/messages",
		bytes.NewReader(body))
	if err != nil { return "", err }
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("x-api-key", e.APIKey)
	req.Header.Set("anthropic-version", "2023-06-01")

	client := &http.Client{Timeout: 30 * time.Second}
	resp, err := client.Do(req)
	if err != nil { return "", err }
	defer resp.Body.Close()

	raw, _ := io.ReadAll(resp.Body)
	var cr struct {
		Content []struct {
			Type string `json:"type"`
			Text string `json:"text"`
		} `json:"content"`
		Error *struct{ Message string `json:"message"` } `json:"error"`
	}
	if err := json.Unmarshal(raw, &cr); err != nil { return "", err }
	if cr.Error != nil { return "", fmt.Errorf(cr.Error.Message) }

	var text string
	for _, c := range cr.Content {
		if c.Type == "text" { text += c.Text }
	}
	return strings.TrimSpace(text), nil
}

// ── ISL mapping ───────────────────────────────────────

func layerToISL(layer, url string) [4]byte {
	// hash URL để lấy group + id
	h := 0
	for _, c := range url { h = h*31 + int(c) }
	grp := byte(h & 0xFF)
	id  := byte((h >> 8) & 0xFF)

	switch strings.ToUpper(layer) {
	case "L": return [4]byte{0x01, grp, 0x00, id} // Script
	case "N": return [4]byte{0x03, grp, 0x00, id} // Number
	case "M": return [4]byte{0x05, grp, 0x00, id} // Math
	case "P": return [4]byte{0x04, grp, 0x00, id} // Punct
	default:  return [4]byte{0x07, grp, 0x00, id} // Symbol
	}
}

func normalizeSDF(sdf [3]float64) [3]float64 {
	clamp := func(v float64) float64 {
		if v < -1 { return -1 }
		if v > 1  { return 1 }
		if math.IsNaN(v) { return 0 }
		return v
	}
	return [3]float64{clamp(sdf[0]), clamp(sdf[1]), clamp(sdf[2])}
}

func slugify(s string) string {
	words := strings.Fields(strings.ToLower(s))
	if len(words) > 4 { words = words[:4] }
	var parts []string
	for _, w := range words {
		clean := strings.Map(func(r rune) rune {
			if (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') {
				return r
			}
			return -1
		}, w)
		if clean != "" { parts = append(parts, clean) }
	}
	if len(parts) == 0 { return "unknown" }
	return strings.Join(parts, "-")
}
