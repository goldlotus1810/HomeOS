// Package web — WebAgent
// Fetch URL → strip HTML → extract concepts → ghi WORLDTREE/learned/

package web

import (
	"bytes"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"time"
	"unicode/utf8"
)

// ── FETCH ────────────────────────────────────────────

// FetchResult — kết quả fetch URL
type FetchResult struct {
	URL       string
	Title     string
	PlainText string // đã strip HTML
	WordCount int
	Hash      string // SHA256 của URL (dùng làm ID)
	FetchedAt time.Time
}

// Fetch — lấy nội dung URL, trả về plain text
func Fetch(rawURL string) (*FetchResult, error) {
	// validate URL
	u, err := url.ParseRequestURI(rawURL)
	if err != nil {
		return nil, fmt.Errorf("web: invalid URL: %w", err)
	}
	if u.Scheme != "http" && u.Scheme != "https" {
		return nil, fmt.Errorf("web: only http/https supported")
	}

	client := &http.Client{Timeout: 15 * time.Second}
	req, err := http.NewRequest("GET", rawURL, nil)
	if err != nil {
		return nil, fmt.Errorf("web: build request: %w", err)
	}
	req.Header.Set("User-Agent",
		"Mozilla/5.0 (compatible; HomeOS/1.0; +http://localhost)")
	req.Header.Set("Accept", "text/html,application/xhtml+xml,text/plain")

	resp, err := client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("web: fetch: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("web: HTTP %d", resp.StatusCode)
	}

	// đọc tối đa 2MB
	limited := io.LimitReader(resp.Body, 2*1024*1024)
	body, err := io.ReadAll(limited)
	if err != nil {
		return nil, fmt.Errorf("web: read body: %w", err)
	}

	contentType := resp.Header.Get("Content-Type")
	var plain, title string

	if strings.Contains(contentType, "text/html") ||
		strings.Contains(contentType, "xhtml") {
		title, plain = stripHTML(string(body))
	} else {
		// plain text / markdown
		plain = string(body)
		title = rawURL
	}

	// làm sạch
	plain = cleanText(plain)

	// giới hạn 8000 từ để gửi Claude
	plain = truncateWords(plain, 8000)

	h := sha256.Sum256([]byte(rawURL))
	return &FetchResult{
		URL:       rawURL,
		Title:     title,
		PlainText: plain,
		WordCount: countWords(plain),
		Hash:      fmt.Sprintf("%x", h[:8]),
		FetchedAt: time.Now(),
	}, nil
}

// stripHTML — bỏ tags, giữ text + title
func stripHTML(html string) (title, text string) {
	// lấy title
	titleRe := regexp.MustCompile(`(?i)<title[^>]*>(.*?)</title>`)
	if m := titleRe.FindStringSubmatch(html); len(m) > 1 {
		title = cleanTag(m[1])
	}

	// bỏ script, style, nav, footer, header
	removeRe := regexp.MustCompile(
		`(?is)<(script|style|nav|footer|header|aside|form|button)[^>]*>.*?</\1>`)
	html = removeRe.ReplaceAllString(html, " ")

	// bỏ tất cả tags còn lại
	tagRe := regexp.MustCompile(`<[^>]+>`)
	text = tagRe.ReplaceAllString(html, " ")

	// decode HTML entities
	text = htmlDecode(text)
	return
}

var entityMap = map[string]string{
	"&amp;": "&", "&lt;": "<", "&gt;": ">",
	"&quot;": `"`, "&#39;": "'", "&nbsp;": " ",
	"&mdash;": "—", "&ndash;": "–", "&hellip;": "...",
}

func htmlDecode(s string) string {
	for ent, rep := range entityMap {
		s = strings.ReplaceAll(s, ent, rep)
	}
	// numeric entities &#NNN;
	numRe := regexp.MustCompile(`&#(\d+);`)
	s = numRe.ReplaceAllStringFunc(s, func(m string) string {
		sub := numRe.FindStringSubmatch(m)
		if len(sub) < 2 { return m }
		var n int
		fmt.Sscanf(sub[1], "%d", &n)
		return string(rune(n))
	})
	return s
}

func cleanTag(s string) string {
	tagRe := regexp.MustCompile(`<[^>]+>`)
	return strings.TrimSpace(tagRe.ReplaceAllString(s, ""))
}

func cleanText(s string) string {
	// nhiều spaces/newlines → 1
	spaceRe := regexp.MustCompile(`[ \t]+`)
	s = spaceRe.ReplaceAllString(s, " ")
	nlRe := regexp.MustCompile(`\n{3,}`)
	s = nlRe.ReplaceAllString(s, "\n\n")
	return strings.TrimSpace(s)
}

func countWords(s string) int {
	return len(strings.Fields(s))
}

func truncateWords(s string, maxWords int) string {
	words := strings.Fields(s)
	if len(words) <= maxWords { return s }
	return strings.Join(words[:maxWords], " ") + " …"
}

// ── KNOWLEDGE NODE ────────────────────────────────────

// KNode — 1 khái niệm đã học từ URL
type KNode struct {
	// identity
	ID      string    `json:"id"`       // URL hash
	Name    string    `json:"name"`     // tên khái niệm chính
	Title   string    `json:"title"`    // tiêu đề trang
	URL     string    `json:"url"`
	LearnedAt time.Time `json:"learned_at"`

	// ○-lang representation
	Symbol  string    `json:"symbol"`   // ký hiệu tóm tắt
	ISL     [4]byte   `json:"isl"`      // [layer, group, type, id]
	SDF     [3]float64 `json:"sdf"`     // vị trí trong không gian tri thức

	// knowledge
	Summary string    `json:"summary"`  // 1-2 câu tóm tắt
	Facts   []Fact    `json:"facts"`    // danh sách fact ngắn
	Tags    []string  `json:"tags"`     // từ khóa

	// relations (tên node khác)
	Related []string  `json:"related"`

	// confidence
	Confidence float64 `json:"confidence"`
	Source     string  `json:"source"` // "web"
}

// Fact — 1 điều đã học
type Fact struct {
	Symbol string `json:"sym"`  // ○-lang symbols
	Text   string `json:"text"` // tiếng Anh/Việt
}

// ── WORLDTREE WRITER ─────────────────────────────────

// NodeStore — ghi/đọc nodes từ WORLDTREE/learned/
type NodeStore struct {
	dir string // đường dẫn đến WORLDTREE/learned/
}

func NewNodeStore(worldtreeDir string) (*NodeStore, error) {
	dir := filepath.Join(worldtreeDir, "learned")
	if err := os.MkdirAll(dir, 0755); err != nil {
		return nil, fmt.Errorf("nodestore: mkdir: %w", err)
	}
	return &NodeStore{dir: dir}, nil
}

// Write — ghi node vào WORLDTREE (append-only: không ghi đè, chỉ thêm version mới)
func (s *NodeStore) Write(n *KNode) error {
	// tên file: {name}.○node (hoặc {id}.○node nếu name có ký tự lạ)
	safeName := safePath(n.Name)
	if safeName == "" { safeName = n.ID }

	// metadata JSON (nhỏ, human-readable)
	metaPath := filepath.Join(s.dir, safeName+".○node.json")
	metaBytes, err := json.MarshalIndent(n, "", "  ")
	if err != nil { return fmt.Errorf("nodestore: marshal: %w", err) }

	// KHÔNG ghi đè — nếu đã tồn tại thì tạo version mới
	finalPath := metaPath
	if fileExists(metaPath) {
		ts := n.LearnedAt.Format("20060102-150405")
		finalPath = filepath.Join(s.dir,
			safeName+"."+ts+".○node.json")
	}

	if err := os.WriteFile(finalPath, metaBytes, 0644); err != nil {
		return fmt.Errorf("nodestore: write: %w", err)
	}

	// ghi ISL binary (SILK format)
	binPath := strings.TrimSuffix(finalPath, ".json") + ".slk"
	if err := s.writeBinary(n, binPath); err != nil {
		// binary optional — không fail nếu lỗi
		_ = err
	}

	return nil
}

// writeBinary — ghi ISL binary stream
// Format: SILK header + tokens
func (s *NodeStore) writeBinary(n *KNode, path string) error {
	// encode tối giản: mỗi fact symbol → ISL tokens
	// Header: magic ○SLK
	magic := []byte{0xE2, 0x97, 0x8B, 0x53, 0x4C, 0x4B} // ○SLK
	var buf bytes.Buffer
	buf.Write(magic)
	buf.WriteByte(1) // version
	buf.WriteByte(0) // flags

	// encode name as UTF-32 tokens
	runes := []rune(n.Symbol + " " + n.Name)
	// nTokens (4 bytes)
	nTok := uint32(len(runes))
	buf.WriteByte(byte(nTok >> 24))
	buf.WriteByte(byte(nTok >> 16))
	buf.WriteByte(byte(nTok >> 8))
	buf.WriteByte(byte(nTok))

	for _, r := range runes {
		cp := uint32(r)
		// codepoint (4 bytes)
		buf.WriteByte(byte(cp >> 24))
		buf.WriteByte(byte(cp >> 16))
		buf.WriteByte(byte(cp >> 8))
		buf.WriteByte(byte(cp))
		// isl (4 bytes)
		buf.Write(n.ISL[:])
		// attr (4 bytes) — zero
		buf.Write([]byte{0, 0, 0, 0})
	}

	return os.WriteFile(path, buf.Bytes(), 0644)
}

// Load — đọc node theo tên
func (s *NodeStore) Load(name string) (*KNode, error) {
	path := filepath.Join(s.dir, safePath(name)+".○node.json")
	b, err := os.ReadFile(path)
	if err != nil { return nil, err }
	var n KNode
	return &n, json.Unmarshal(b, &n)
}

// Search — tìm nodes theo SDF distance (đơn giản: scan tất cả)
func (s *NodeStore) Search(sdf [3]float64, limit int) ([]*KNode, error) {
	entries, err := os.ReadDir(s.dir)
	if err != nil { return nil, err }

	type scored struct {
		node *KNode
		dist float64
	}
	var all []scored

	for _, e := range entries {
		if !strings.HasSuffix(e.Name(), ".○node.json") { continue }
		// skip versioned files
		if strings.Count(e.Name(), ".") > 2 { continue }

		b, err := os.ReadFile(filepath.Join(s.dir, e.Name()))
		if err != nil { continue }
		var n KNode
		if err := json.Unmarshal(b, &n); err != nil { continue }

		dist := sdfDist(n.SDF, sdf)
		all = append(all, scored{&n, dist})
	}

	// sort by distance
	for i := 1; i < len(all); i++ {
		for j := i; j > 0 && all[j].dist < all[j-1].dist; j-- {
			all[j], all[j-1] = all[j-1], all[j]
		}
	}

	var result []*KNode
	for i, s := range all {
		if i >= limit { break }
		result = append(result, s.node)
	}
	return result, nil
}

// List — liệt kê tất cả nodes
func (s *NodeStore) List() ([]*KNode, error) {
	entries, err := os.ReadDir(s.dir)
	if err != nil { return nil, err }
	var result []*KNode
	for _, e := range entries {
		if !strings.HasSuffix(e.Name(), ".○node.json") { continue }
		if strings.Count(e.Name(), ".") > 2 { continue }
		b, err := os.ReadFile(filepath.Join(s.dir, e.Name()))
		if err != nil { continue }
		var n KNode
		if err := json.Unmarshal(b, &n); err != nil { continue }
		result = append(result, &n)
	}
	return result, nil
}

func (s *NodeStore) Count() int {
	entries, _ := filepath.Glob(filepath.Join(s.dir, "*.○node.json"))
	return len(entries)
}

// ── helpers ───────────────────────────────────────────

func sdfDist(a, b [3]float64) float64 {
	dx := a[0] - b[0]
	dy := a[1] - b[1]
	dz := a[2] - b[2]
	return dx*dx + dy*dy + dz*dz // squared distance (no sqrt needed for comparison)
}

func safePath(s string) string {
	if !utf8.ValidString(s) { return "unknown" }
	// giữ chữ cái, số, dấu gạch
	var b strings.Builder
	for _, r := range strings.ToLower(s) {
		if (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') ||
			r == '-' || r == '_' {
			b.WriteRune(r)
		} else if r == ' ' {
			b.WriteRune('-')
		}
	}
	result := b.String()
	if result == "" { return "node" }
	if len(result) > 64 { result = result[:64] }
	return result
}

func fileExists(path string) bool {
	_, err := os.Stat(path)
	return err == nil
}

var _ = bytes.NewBuffer // suppress unused import
