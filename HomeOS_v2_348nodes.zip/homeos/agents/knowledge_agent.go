// Package agents — KnowledgeAgent
// Wrap KAgent vào Agent interface để đăng ký trong Bus
// Verb: KNOW SEARCH NEAR LANG RELATE UNION STATS DANGER

package agents

import (
	"fmt"
	"strings"
	"time"

	"github.com/goldlotus1810/HomeOS/worldtree/tools"
)

type KnowledgeAgent struct {
	kagent *tools.KAgent
}

func NewKnowledgeAgent(worldtreeDir string) (*KnowledgeAgent, error) {
	ka, err := tools.NewKAgent(worldtreeDir)
	if err != nil {
		return nil, fmt.Errorf("kagent init: %w", err)
	}
	return &KnowledgeAgent{kagent: ka}, nil
}

func (a *KnowledgeAgent) Name() string { return "KnowledgeAgent" }

func (a *KnowledgeAgent) CanHandle(i *Intent) bool {
	return i.Agent == "KnowledgeAgent" ||
		i.Chief == "KnowledgeChief" ||
		i.Verb == "KNOW" ||
		i.Verb == "SEARCH" ||
		i.Verb == "NEAR" ||
		i.Verb == "LANG" ||
		i.Verb == "RELATE" ||
		i.Verb == "UNION" ||
		i.Verb == "STATS" ||
		i.Verb == "DANGER"
}

func (a *KnowledgeAgent) Execute(i *Intent) *Result {
	query := fmt.Sprintf("%v", i.Value)
	if query == "" || query == "<nil>" {
		query = i.Target
	}
	if query == "" {
		query = i.Query()
	}

	intent := tools.KIntent{
		Verb:  i.Verb,
		Query: query,
		Limit: 5,
		Depth: 2,
	}

	// NEAR: parse SDF từ Value nếu có
	if i.Verb == "NEAR" && i.Value != nil {
		if sdfSlice, ok := i.Value.([]float64); ok && len(sdfSlice) == 3 {
			intent.SDF = [3]float64{sdfSlice[0], sdfSlice[1], sdfSlice[2]}
		}
	}

	r := a.kagent.Execute(intent)

	if !r.OK && len(r.Nodes) == 0 {
		return &Result{
			Agent:   a.Name(),
			OK:      false,
			Value:   r.Error,
			Symbols: "○⊗",
			TS:      time.Now(),
			Error:   r.Error,
		}
	}

	// format output
	text := tools.FormatResult(r)

	return &Result{
		Agent:   a.Name(),
		OK:      true,
		Value:   map[string]any{
			"nodes":  r.Nodes,
			"stats":  r.Stats,
			"text":   text,
			"count":  len(r.Nodes),
			"verb":   r.Verb,
		},
		Symbols: fmt.Sprintf("○⧺%s⧺%d", r.Verb, len(r.Nodes)),
		TS:      time.Now(),
	}
}

func (a *KnowledgeAgent) Status() map[string]any {
	return map[string]any{
		"nodes": a.kagent.Count(),
	}
}

// KAgent — trả về KAgent để AAM dùng trực tiếp
func (a *KnowledgeAgent) KAgent() *tools.KAgent {
	return a.kagent
}

// ── Intent helper ─────────────────────────────────────

// Query — lấy query string từ Intent (thêm method vào Intent)
func (i *Intent) Query() string {
	parts := []string{}
	if i.Target != "" {
		parts = append(parts, i.Target)
	}
	if v := fmt.Sprintf("%v", i.Value); v != "" && v != "<nil>" {
		parts = append(parts, v)
	}
	return strings.Join(parts, " ")
}
