package agents

import (
	"fmt"
	"strings"
	"time"

	"github.com/goldlotus1810/HomeOS/agents/web"
)

// WebAgent — học từ URL, ghi vào WORLDTREE
type WebAgent struct {
	extractor *web.Extractor
	store     *web.NodeStore
}

func NewWebAgent(apiKey, worldtreeDir string) (*WebAgent, error) {
	store, err := web.NewNodeStore(worldtreeDir)
	if err != nil {
		return nil, err
	}
	return &WebAgent{
		extractor: web.NewExtractor(apiKey, store),
		store:     store,
	}, nil
}

func (a *WebAgent) Name() string { return "WebAgent" }

func (a *WebAgent) CanHandle(i *Intent) bool {
	return i.Agent == "WebAgent" ||
		i.Chief == "WebChief" ||
		i.Verb == "LEARN" ||
		i.Verb == "READ" ||
		(i.Verb == "GET" && isURL(fmt.Sprintf("%v", i.Value)))
}

func (a *WebAgent) Execute(i *Intent) *Result {
	rawURL := fmt.Sprintf("%v", i.Value)
	if rawURL == "" || rawURL == "<nil>" {
		rawURL = i.Target
	}
	if !isURL(rawURL) {
		return errResult(a.Name(), "cần URL hợp lệ (http/https)")
	}

	switch i.Verb {
	case "LEARN", "READ", "GET":
		node, err := a.extractor.LearnURL(rawURL)
		if err != nil {
			return &Result{
				Agent:   a.Name(),
				OK:      false,
				Symbols: "⊗⧺LEARN",
				TS:      time.Now(),
				Error:   err.Error(),
			}
		}

		summary := fmt.Sprintf(
			"✓ đã học: %s\n  symbol: %s\n  summary: %s\n  facts: %d\n  tags: %s",
			node.Name,
			node.Symbol,
			node.Summary,
			len(node.Facts),
			strings.Join(node.Tags, ", "),
		)

		return &Result{
			Agent:   a.Name(),
			OK:      true,
			Value:   map[string]any{
				"node":    node,
				"summary": summary,
			},
			Symbols: fmt.Sprintf("📖⧺%s⧺→⧺○⧺✓", node.Symbol),
			TS:      time.Now(),
		}

	case "QUERY", "LIST":
		nodes, err := a.store.List()
		if err != nil {
			return errResult(a.Name(), err.Error())
		}
		var lines []string
		for _, n := range nodes {
			lines = append(lines, fmt.Sprintf(
				"%s %s — %s", n.Symbol, n.Name, n.Summary))
		}
		return ok(a.Name(), true,
			map[string]any{
				"count": len(nodes),
				"nodes": lines,
			},
			"", fmt.Sprintf("○⩵%d nodes", len(nodes)))
	}

	return errResult(a.Name(), "unknown verb: "+i.Verb)
}

func (a *WebAgent) Status() map[string]any {
	return map[string]any{
		"learned": a.store.Count(),
	}
}

func isURL(s string) bool {
	return strings.HasPrefix(s, "http://") ||
		strings.HasPrefix(s, "https://")
}

// LearnedCount — số nodes đã học
func (a *WebAgent) LearnedCount() int {
	return a.store.Count()
}
