//go:build linux
// +build linux

package system

import (
	"bufio"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"
)

func GetHardware() (*HardwareInfo, error) {
	h := &HardwareInfo{}
	h.CPU    = readCPUInfo()
	mem, err := readMemInfo()
	if err == nil {
		h.Memory = mem
		h.Memory.Processes = topMemProcesses(10)
	}
	h.Disk   = readDiskInfo()
	h.Load   = readLoadAvg()
	h.Uptime = readUptime()
	return h, nil
}

func readCPUInfo() CPUInfo {
	ci := CPUInfo{}
	f, err := os.Open("/proc/cpuinfo")
	if err != nil { return ci }
	defer f.Close()
	sc := bufio.NewScanner(f)
	cores := 0
	for sc.Scan() {
		line := sc.Text()
		if strings.HasPrefix(line, "model name") && ci.Model == "" {
			parts := strings.SplitN(line, ":", 2)
			if len(parts) == 2 { ci.Model = strings.TrimSpace(parts[1]) }
		}
		if strings.HasPrefix(line, "processor") { cores++ }
		if strings.HasPrefix(line, "cpu MHz") && ci.Freq == "" {
			parts := strings.SplitN(line, ":", 2)
			if len(parts) == 2 { ci.Freq = strings.TrimSpace(parts[1]) }
		}
	}
	ci.Cores    = cores
	ci.UsagePct = readCPUUsage()
	return ci
}

func readCPUUsage() float64 {
	sample := func() (idle, total uint64) {
		f, err := os.Open("/proc/stat")
		if err != nil { return }
		defer f.Close()
		sc := bufio.NewScanner(f)
		for sc.Scan() {
			line := sc.Text()
			if !strings.HasPrefix(line, "cpu ") { continue }
			fields := strings.Fields(line)
			if len(fields) < 5 { continue }
			vals := make([]uint64, len(fields)-1)
			for i, s := range fields[1:] {
				vals[i], _ = strconv.ParseUint(s, 10, 64)
				total += vals[i]
			}
			if len(vals) > 3 { idle = vals[3] }
		}
		return
	}
	idle1, total1 := sample()
	time.Sleep(200 * time.Millisecond)
	idle2, total2 := sample()
	dt := float64(total2 - total1)
	di := float64(idle2 - idle1)
	if dt == 0 { return 0 }
	return (1 - di/dt) * 100
}

func readMemInfo() (MemInfo, error) {
	m := MemInfo{}
	f, err := os.Open("/proc/meminfo")
	if err != nil { return m, err }
	defer f.Close()
	vals := map[string]int{}
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		fields := strings.Fields(sc.Text())
		if len(fields) < 2 { continue }
		key := strings.TrimSuffix(fields[0], ":")
		val, _ := strconv.Atoi(fields[1])
		vals[key] = val
	}
	total   := vals["MemTotal"]
	free    := vals["MemFree"]
	buffers := vals["Buffers"]
	cached  := vals["Cached"] + vals["SReclaimable"]
	used    := total - free - buffers - cached
	m.TotalMB = total / 1024
	m.UsedMB  = used  / 1024
	m.FreeMB  = (free + buffers + cached) / 1024
	if total > 0 { m.UsePct = float64(used) / float64(total) * 100 }
	return m, nil
}

func topMemProcesses(n int) []ProcMem {
	entries, err := os.ReadDir("/proc")
	if err != nil { return nil }
	var procs []ProcMem
	for _, e := range entries {
		if !e.IsDir() { continue }
		pid, err := strconv.Atoi(e.Name())
		if err != nil { continue }
		commBytes, err := os.ReadFile(fmt.Sprintf("/proc/%d/comm", pid))
		if err != nil { continue }
		name := strings.TrimSpace(string(commBytes))
		statusF, err := os.Open(fmt.Sprintf("/proc/%d/status", pid))
		if err != nil { continue }
		rss := 0
		sc := bufio.NewScanner(statusF)
		for sc.Scan() {
			line := sc.Text()
			if strings.HasPrefix(line, "VmRSS:") {
				fields := strings.Fields(line)
				if len(fields) >= 2 { rss, _ = strconv.Atoi(fields[1]) }
				break
			}
		}
		statusF.Close()
		if rss == 0 { continue }
		procs = append(procs, ProcMem{PID: pid, Name: name, RSS_MB: float64(rss) / 1024})
	}
	sort.Slice(procs, func(i, j int) bool { return procs[i].RSS_MB > procs[j].RSS_MB })
	if len(procs) > n { procs = procs[:n] }
	return procs
}

func readDiskInfo() []DiskInfo {
	out, err := exec.Command("df", "-B1", "--output=source,target,size,used,pcent").Output()
	if err != nil { return nil }
	var disks []DiskInfo
	for _, line := range strings.Split(string(out), "\n")[1:] {
		fields := strings.Fields(line)
		if len(fields) < 5 { continue }
		if !strings.HasPrefix(fields[0], "/dev/") { continue }
		total, _ := strconv.ParseInt(fields[2], 10, 64)
		used,  _ := strconv.ParseInt(fields[3], 10, 64)
		pct   := strings.TrimSuffix(fields[4], "%")
		pctF, _ := strconv.ParseFloat(pct, 64)
		disks = append(disks, DiskInfo{
			Mount: fields[1], Device: fields[0],
			TotalGB: float64(total)/1e9, UsedGB: float64(used)/1e9, UsePct: pctF,
		})
	}
	return disks
}

func readLoadAvg() LoadInfo {
	b, err := os.ReadFile("/proc/loadavg")
	if err != nil { return LoadInfo{} }
	fields := strings.Fields(string(b))
	if len(fields) < 3 { return LoadInfo{} }
	l1,  _ := strconv.ParseFloat(fields[0], 64)
	l5,  _ := strconv.ParseFloat(fields[1], 64)
	l15, _ := strconv.ParseFloat(fields[2], 64)
	return LoadInfo{l1, l5, l15}
}

func readUptime() string {
	b, err := os.ReadFile("/proc/uptime")
	if err != nil { return "" }
	fields := strings.Fields(string(b))
	if len(fields) == 0 { return "" }
	secs, _ := strconv.ParseFloat(fields[0], 64)
	d := int(secs) / 86400
	h := (int(secs) % 86400) / 3600
	m := (int(secs) % 3600) / 60
	if d > 0 { return fmt.Sprintf("%dd %dh %dm", d, h, m) }
	return fmt.Sprintf("%dh %dm", h, m)
}

func GetProcesses() ([]ProcessInfo, error) {
	entries, err := os.ReadDir("/proc")
	if err != nil { return nil, err }
	var procs []ProcessInfo
	for _, e := range entries {
		if !e.IsDir() { continue }
		pid, err := strconv.Atoi(e.Name())
		if err != nil { continue }
		p := readProcess(pid)
		if p == nil { continue }
		procs = append(procs, *p)
	}
	sort.Slice(procs, func(i, j int) bool { return procs[i].RSS_MB > procs[j].RSS_MB })
	return procs, nil
}

func readProcess(pid int) *ProcessInfo {
	base := fmt.Sprintf("/proc/%d", pid)
	commB, err := os.ReadFile(base + "/comm")
	if err != nil { return nil }
	name := strings.TrimSpace(string(commB))
	sf, err := os.Open(base + "/status")
	if err != nil { return nil }
	defer sf.Close()
	p := &ProcessInfo{PID: pid, Name: name}
	sc := bufio.NewScanner(sf)
	for sc.Scan() {
		line := sc.Text()
		fields := strings.Fields(line)
		if len(fields) < 2 { continue }
		key := strings.TrimSuffix(fields[0], ":")
		switch key {
		case "State":
			p.State = fields[1]
		case "VmRSS":
			rss, _ := strconv.Atoi(fields[1])
			p.RSS_MB = float64(rss) / 1024
		case "Uid":
			uid, _ := strconv.Atoi(fields[1])
			p.User = uidToName(uid)
		}
	}
	cmdB, _ := os.ReadFile(base + "/cmdline")
	cmdline := strings.ReplaceAll(string(cmdB), "\x00", " ")
	if len(cmdline) > 80 { cmdline = cmdline[:80] + "…" }
	p.CmdLine  = strings.TrimSpace(cmdline)
	p.Category = categorize(p)
	p.CanKill  = canKill(p)
	return p
}

func uidToName(uid int) string {
	if uid == 0 { return "root" }
	b, err := os.ReadFile("/etc/passwd")
	if err != nil { return strconv.Itoa(uid) }
	for _, line := range strings.Split(string(b), "\n") {
		fields := strings.Split(line, ":")
		if len(fields) < 3 { continue }
		if fields[2] == strconv.Itoa(uid) { return fields[0] }
	}
	return strconv.Itoa(uid)
}

func categorize(p *ProcessInfo) string {
	switch {
	case p.State == "Z":                    return "zombie"
	case p.RSS_MB == 0 && p.User == "root": return "kernel"
	case p.User == "root":                  return "system"
	default:                                return "user"
	}
}

func canKill(p *ProcessInfo) bool {
	if p.PID == 1 { return false }
	if p.Category == "kernel" || p.Category == "zombie" { return false }
	if p.Name == "systemd" || p.Name == "init" { return false }
	return true
}

func FindSuspicious(procs []ProcessInfo) []SuspiciousProcess {
	var result []SuspiciousProcess
	load := readLoadAvg()
	totalMem, _ := readMemInfo()
	for _, p := range procs {
		var reasons []string
		if p.State == "Z" {
			reasons = append(reasons, "zombie process")
		}
		if p.RSS_MB > 300 && p.Category == "user" {
			reasons = append(reasons, fmt.Sprintf("dùng %.0fMB RAM", p.RSS_MB))
		}
		if p.CPU_Pct > 20 && load.Load1 > float64(getCPUCores())*0.8 {
			reasons = append(reasons, fmt.Sprintf("CPU %.1f%% khi load cao", p.CPU_Pct))
		}
		if len(reasons) == 0 { continue }
		_ = totalMem
		sp := SuspiciousProcess{ProcessInfo: p, Reason: strings.Join(reasons, "; ")}
		if svc := findService(p.Name); svc != "" {
			sp.Action = "stop-service"; sp.ServiceName = svc
		} else if p.CanKill {
			sp.Action = "kill"
		}
		result = append(result, sp)
	}
	return result
}

func findService(procName string) string {
	out, err := exec.Command("systemctl", "list-units", "--type=service",
		"--state=running", "--no-pager", "--plain").Output()
	if err != nil { return "" }
	for _, line := range strings.Split(string(out), "\n") {
		if strings.Contains(strings.ToLower(line), strings.ToLower(procName)) {
			fields := strings.Fields(line)
			if len(fields) > 0 { return fields[0] }
		}
	}
	return ""
}

func getCPUCores() int {
	entries, _ := filepath.Glob("/sys/devices/system/cpu/cpu[0-9]*")
	if len(entries) > 0 { return len(entries) }
	return 4
}

func KillProcess(pid int) ActionResult {
	out, err := exec.Command("kill", "-15", strconv.Itoa(pid)).CombinedOutput()
	if err != nil {
		out, err = exec.Command("kill", "-9", strconv.Itoa(pid)).CombinedOutput()
		if err != nil { return ActionResult{false, fmt.Sprintf("kill %d: %s %s", pid, err, out)} }
	}
	return ActionResult{true, fmt.Sprintf("process %d killed", pid)}
}

func StopService(name string) ActionResult {
	out, err := exec.Command("systemctl", "--user", "stop", name).CombinedOutput()
	if err != nil {
		out, err = exec.Command("systemctl", "stop", name).CombinedOutput()
		if err != nil { return ActionResult{false, fmt.Sprintf("stop %s: %s %s", name, err, out)} }
	}
	return ActionResult{true, fmt.Sprintf("service %s stopped", name)}
}

func UninstallPackage(pkg string) ActionResult {
	out, err := exec.Command("pacman", "-Rns", "--noconfirm", pkg).CombinedOutput()
	if err != nil { return ActionResult{false, fmt.Sprintf("uninstall %s: %s\n%s", pkg, err, out)} }
	return ActionResult{true, fmt.Sprintf("uninstalled %s", pkg)}
}

func Summary() string {
	h, _ := GetHardware()
	if h == nil { return "không đọc được hardware info" }
	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("CPU: %s (%d cores, %.1f%%)\n", h.CPU.Model, h.CPU.Cores, h.CPU.UsagePct))
	sb.WriteString(fmt.Sprintf("RAM: %dMB / %dMB (%.1f%%)\n", h.Memory.UsedMB, h.Memory.TotalMB, h.Memory.UsePct))
	for _, d := range h.Disk {
		if d.Mount == "/" || strings.HasPrefix(d.Mount, "/home") {
			sb.WriteString(fmt.Sprintf("Disk %s: %.1fGB / %.1fGB (%.0f%%)\n", d.Mount, d.UsedGB, d.TotalGB, d.UsePct))
		}
	}
	sb.WriteString(fmt.Sprintf("Load: %.2f %.2f %.2f · Uptime: %s", h.Load.Load1, h.Load.Load5, h.Load.Load15, h.Uptime))
	return sb.String()
}
