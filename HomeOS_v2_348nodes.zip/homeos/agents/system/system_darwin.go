//go:build darwin
// +build darwin

package system

import (
	"fmt"
	"os/exec"
	"strings"
)

// macOS stubs — dùng sysctl thay vì /proc

func GetHardware() (*HardwareInfo, error) {
	h := &HardwareInfo{}
	out, _ := exec.Command("sysctl", "-n", "machdep.cpu.brand_string").Output()
	h.CPU.Model = strings.TrimSpace(string(out))
	h.CPU.Cores = 4
	h.Uptime = readUptime()
	return h, nil
}

func Summary() string {
	h, _ := GetHardware()
	if h == nil { return "macOS: không đọc được hardware info" }
	return fmt.Sprintf("CPU: %s (%d cores)\nUptime: %s", h.CPU.Model, h.CPU.Cores, h.Uptime)
}

func GetProcesses() ([]ProcessInfo, error) {
	return []ProcessInfo{}, nil
}

func FindSuspicious(procs []ProcessInfo) []SuspiciousProcess {
	return nil
}

func KillProcess(pid int) ActionResult {
	out, err := exec.Command("kill", "-15", fmt.Sprintf("%d", pid)).CombinedOutput()
	if err != nil {
		return ActionResult{false, fmt.Sprintf("kill: %s %s", err, out)}
	}
	return ActionResult{true, fmt.Sprintf("process %d killed", pid)}
}

func StopService(name string) ActionResult {
	return ActionResult{false, "macOS: dùng launchctl, chưa implement"}
}

func UninstallPackage(pkg string) ActionResult {
	out, err := exec.Command("brew", "uninstall", pkg).CombinedOutput()
	if err != nil {
		return ActionResult{false, string(out)}
	}
	return ActionResult{true, fmt.Sprintf("uninstalled %s", pkg)}
}
