//go:build windows
// +build windows

package system

import "fmt"

// Windows stubs

func GetHardware() (*HardwareInfo, error) {
	return &HardwareInfo{CPU: CPUInfo{Model: "Windows CPU", Cores: 4}}, nil
}

func Summary() string {
	return "Windows: hardware info chưa implement"
}

func GetProcesses() ([]ProcessInfo, error) {
	return []ProcessInfo{}, nil
}

func FindSuspicious(procs []ProcessInfo) []SuspiciousProcess {
	return nil
}

func KillProcess(pid int) ActionResult {
	return ActionResult{false, fmt.Sprintf("Windows: dùng taskkill /PID %d", pid)}
}

func StopService(name string) ActionResult {
	return ActionResult{false, fmt.Sprintf("Windows: net stop %s", name)}
}

func UninstallPackage(pkg string) ActionResult {
	return ActionResult{false, fmt.Sprintf("Windows: winget uninstall %s", pkg)}
}
