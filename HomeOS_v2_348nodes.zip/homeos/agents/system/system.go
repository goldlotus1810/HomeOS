// Package system — platform-independent types
// Implementations: system_linux.go, system_darwin.go, system_windows.go

package system

// ── Shared Types ─────────────────────────────────────

type HardwareInfo struct {
	CPU     CPUInfo    `json:"cpu"`
	Memory  MemInfo    `json:"memory"`
	Disk    []DiskInfo `json:"disk"`
	Load    LoadInfo   `json:"load"`
	Uptime  string     `json:"uptime"`
}

type CPUInfo struct {
	Model    string  `json:"model"`
	Cores    int     `json:"cores"`
	UsagePct float64 `json:"usage_pct"`
	Freq     string  `json:"freq_mhz"`
}

type MemInfo struct {
	TotalMB   int       `json:"total_mb"`
	UsedMB    int       `json:"used_mb"`
	FreeMB    int       `json:"free_mb"`
	UsePct    float64   `json:"use_pct"`
	Processes []ProcMem `json:"top_processes"`
}

type ProcMem struct {
	PID    int     `json:"pid"`
	Name   string  `json:"name"`
	RSS_MB float64 `json:"rss_mb"`
	UsePct float64 `json:"use_pct"`
}

type DiskInfo struct {
	Mount   string  `json:"mount"`
	Device  string  `json:"device"`
	TotalGB float64 `json:"total_gb"`
	UsedGB  float64 `json:"used_gb"`
	UsePct  float64 `json:"use_pct"`
}

type LoadInfo struct {
	Load1  float64 `json:"load1"`
	Load5  float64 `json:"load5"`
	Load15 float64 `json:"load15"`
}

type ProcessInfo struct {
	PID      int     `json:"pid"`
	Name     string  `json:"name"`
	User     string  `json:"user"`
	CPU_Pct  float64 `json:"cpu_pct"`
	RSS_MB   float64 `json:"rss_mb"`
	State    string  `json:"state"`
	CmdLine  string  `json:"cmdline"`
	Category string  `json:"category"`
	CanKill  bool    `json:"can_kill"`
}

type SuspiciousProcess struct {
	ProcessInfo
	Reason      string `json:"reason"`
	Action      string `json:"action"`
	ServiceName string `json:"service,omitempty"`
}

type ActionResult struct {
	OK      bool   `json:"ok"`
	Message string `json:"message"`
}
