// Package agents — HomeOS agent bus
// Mỗi agent nhận Intent → thực thi → trả Result
// Giao tiếp nội bộ bằng ○-lang (Intent struct)
// KHÔNG BAO GIỜ nói chuyện trực tiếp với người dùng

package agents

import (
	"fmt"
	"sync"
	"time"
)

// Intent — từ AAM gửi xuống (mirror aam.Intent, tránh circular import)
type Intent struct {
	Verb    string  `json:"verb"`
	Chief   string  `json:"chief"`
	Agent   string  `json:"agent"`
	Target  string  `json:"target"`
	Value   any     `json:"value"`
	Unit    string  `json:"unit"`
	Symbols string  `json:"symbols"`
}

// Result — agent trả về
type Result struct {
	Agent   string    `json:"agent"`
	OK      bool      `json:"ok"`
	Value   any       `json:"value,omitempty"`
	Unit    string    `json:"unit,omitempty"`
	Symbols string    `json:"symbols"` // ○-lang response
	TS      time.Time `json:"ts"`
	Error   string    `json:"error,omitempty"`
}

// Agent interface
type Agent interface {
	Name() string
	CanHandle(intent *Intent) bool
	Execute(intent *Intent) *Result
	Status() map[string]any
}

// ── BUS ───────────────────────────────────────────────

type Bus struct {
	mu     sync.RWMutex
	agents map[string]Agent
}

func NewBus() *Bus {
	return &Bus{agents: make(map[string]Agent)}
}

func (b *Bus) Register(a Agent) {
	b.mu.Lock()
	b.agents[a.Name()] = a
	b.mu.Unlock()
}

func (b *Bus) Execute(intent *Intent) (*Result, error) {
	b.mu.RLock()
	defer b.mu.RUnlock()
	for _, a := range b.agents {
		if a.CanHandle(intent) {
			return a.Execute(intent), nil
		}
	}
	return &Result{
		Agent:   "Bus",
		OK:      false,
		Symbols: "⊗",
		TS:      time.Now(),
		Error:   fmt.Sprintf("no agent for: %s/%s", intent.Chief, intent.Agent),
	}, nil
}

func (b *Bus) Count() int {
	b.mu.RLock()
	defer b.mu.RUnlock()
	return len(b.agents)
}

func (b *Bus) Status() map[string]any {
	b.mu.RLock()
	defer b.mu.RUnlock()
	out := map[string]any{}
	for name, a := range b.agents {
		out[name] = a.Status()
	}
	return out
}

// ══════════════════════════════════════════════════════
// LIGHT AGENT
// ══════════════════════════════════════════════════════

type LightAgent struct {
	mu     sync.RWMutex
	states map[string]lightState // target → state
}

type lightState struct {
	On         bool    `json:"on"`
	Brightness int     `json:"brightness"` // 0-100
}

func NewLightAgent() *LightAgent {
	return &LightAgent{
		states: map[string]lightState{
			"living_room": {On: false, Brightness: 100},
			"bedroom":     {On: false, Brightness: 80},
			"kitchen":     {On: false, Brightness: 100},
			"bathroom":    {On: false, Brightness: 100},
			"all":         {On: false, Brightness: 100},
		},
	}
}

func (a *LightAgent) Name() string { return "LightAgent" }

func (a *LightAgent) CanHandle(i *Intent) bool {
	return i.Agent == "LightAgent" ||
		(i.Chief == "HomeChief" && i.Agent == "")
}

func (a *LightAgent) Execute(i *Intent) *Result {
	a.mu.Lock()
	defer a.mu.Unlock()

	target := i.Target
	if target == "" { target = "all" }

	switch i.Verb {
	case "ON":
		a.setOn(target, true)
		return ok(a.Name(), true, nil, "", "💡⧺ON⧺✓")
	case "OFF":
		a.setOn(target, false)
		return ok(a.Name(), true, nil, "", "💡⧺OFF⧺✓")
	case "SET":
		if v, ok2 := toFloat(i.Value); ok2 {
			a.setBrightness(target, int(v))
			return ok(a.Name(), true, int(v), "%", fmt.Sprintf("💡≔%.0f%%", v))
		}
		return errResult(a.Name(), "invalid value")
	case "GET", "QUERY":
		st := a.getState(target)
		onStr := "OFF"
		if st.On { onStr = "ON" }
		return ok(a.Name(), true,
			map[string]any{"on": st.On, "brightness": st.Brightness},
			"", fmt.Sprintf("💡⩵%s·%d%%", onStr, st.Brightness))
	}
	return errResult(a.Name(), "unknown verb: "+i.Verb)
}

func (a *LightAgent) Status() map[string]any {
	a.mu.RLock()
	defer a.mu.RUnlock()
	out := map[string]any{}
	for k, v := range a.states {
		out[k] = v
	}
	return out
}

func (a *LightAgent) setOn(target string, on bool) {
	if target == "all" {
		for k, s := range a.states { s.On = on; a.states[k] = s }
		return
	}
	if s, ok := a.states[target]; ok { s.On = on; a.states[target] = s }
}

func (a *LightAgent) setBrightness(target string, b int) {
	if b < 0 { b = 0 }; if b > 100 { b = 100 }
	if target == "all" {
		for k, s := range a.states { s.Brightness = b; a.states[k] = s }
		return
	}
	if s, ok := a.states[target]; ok { s.Brightness = b; a.states[target] = s }
}

func (a *LightAgent) getState(target string) lightState {
	if s, ok := a.states[target]; ok { return s }
	return lightState{}
}

// ══════════════════════════════════════════════════════
// HVAC AGENT
// ══════════════════════════════════════════════════════

type HVACAgent struct {
	mu   sync.RWMutex
	temp float64 // °C setpoint
	mode string  // cool heat fan auto
	on   bool
}

func NewHVACAgent() *HVACAgent {
	return &HVACAgent{temp: 26, mode: "auto", on: false}
}

func (a *HVACAgent) Name() string { return "HVACAgent" }
func (a *HVACAgent) CanHandle(i *Intent) bool {
	return i.Agent == "HVACAgent" ||
		(i.Chief == "HomeChief" &&
			(i.Verb == "SET" || contains(i.Symbols, "🌡")))
}

func (a *HVACAgent) Execute(i *Intent) *Result {
	a.mu.Lock()
	defer a.mu.Unlock()
	switch i.Verb {
	case "ON":
		a.on = true
		return ok(a.Name(), true, nil, "", "🌡⧺ON⧺✓")
	case "OFF":
		a.on = false
		return ok(a.Name(), true, nil, "", "🌡⧺OFF⧺✓")
	case "SET":
		if v, ok2 := toFloat(i.Value); ok2 {
			a.temp = v; a.on = true
			return ok(a.Name(), true, v, "°C", fmt.Sprintf("🌡≔%.0f°C", v))
		}
		return errResult(a.Name(), "invalid value")
	case "GET", "QUERY":
		return ok(a.Name(), true,
			map[string]any{"temp": a.temp, "mode": a.mode, "on": a.on},
			"°C", fmt.Sprintf("🌡⩵%.0f°C·%s", a.temp, a.mode))
	}
	return errResult(a.Name(), "unknown verb")
}

func (a *HVACAgent) Status() map[string]any {
	a.mu.RLock(); defer a.mu.RUnlock()
	return map[string]any{"temp": a.temp, "mode": a.mode, "on": a.on}
}

// ══════════════════════════════════════════════════════
// LOCK AGENT
// ══════════════════════════════════════════════════════

type LockAgent struct {
	mu    sync.RWMutex
	locks map[string]bool // door → locked
}

func NewLockAgent() *LockAgent {
	return &LockAgent{locks: map[string]bool{
		"front_door": true, "back_door": true, "garage": false,
	}}
}

func (a *LockAgent) Name() string { return "LockAgent" }
func (a *LockAgent) CanHandle(i *Intent) bool {
	return i.Agent == "LockAgent" ||
		i.Verb == "LOCK" || i.Verb == "UNLOCK"
}

func (a *LockAgent) Execute(i *Intent) *Result {
	a.mu.Lock(); defer a.mu.Unlock()
	target := i.Target; if target == "" { target = "front_door" }
	switch i.Verb {
	case "LOCK":
		a.locks[target] = true
		return ok(a.Name(), true, nil, "", "🔒⧺✓")
	case "UNLOCK":
		a.locks[target] = false
		return ok(a.Name(), true, nil, "", "🔓⧺✓")
	case "GET", "QUERY":
		locked := a.locks[target]
		sym := "🔒"; if !locked { sym = "🔓" }
		return ok(a.Name(), true, locked, "", sym)
	}
	return errResult(a.Name(), "unknown verb")
}

func (a *LockAgent) Status() map[string]any {
	a.mu.RLock(); defer a.mu.RUnlock()
	out := map[string]any{}
	for k, v := range a.locks { out[k] = v }
	return out
}

// ══════════════════════════════════════════════════════
// BATTERY AGENT
// ══════════════════════════════════════════════════════

type BatteryAgent struct{ level float64 }

func NewBatteryAgent() *BatteryAgent { return &BatteryAgent{level: 78} }
func (a *BatteryAgent) Name() string { return "BatteryAgent" }
func (a *BatteryAgent) CanHandle(i *Intent) bool {
	return i.Agent == "BatteryAgent" || i.Chief == "EnergyChief"
}
func (a *BatteryAgent) Execute(i *Intent) *Result {
	return ok(a.Name(), true, a.level, "%",
		fmt.Sprintf("🔋⩵%.0f%%", a.level))
}
func (a *BatteryAgent) Status() map[string]any {
	return map[string]any{"level": a.level}
}

// ══════════════════════════════════════════════════════
// CAMERA AGENT
// ══════════════════════════════════════════════════════

type CameraAgent struct{ active bool }

func NewCameraAgent() *CameraAgent { return &CameraAgent{} }
func (a *CameraAgent) Name() string { return "CameraAgent" }
func (a *CameraAgent) CanHandle(i *Intent) bool {
	return i.Agent == "CameraAgent" || i.Chief == "VisionChief"
}
func (a *CameraAgent) Execute(i *Intent) *Result {
	switch i.Verb {
	case "ON":  a.active = true;  return ok(a.Name(), true, nil, "", "📷⧺ON⧺✓")
	case "OFF": a.active = false; return ok(a.Name(), true, nil, "", "📷⧺OFF⧺✓")
	default:
		return ok(a.Name(), true,
			map[string]any{"active": a.active, "stream": "rtsp://localhost:8554/cam"},
			"", "📷⩵stream·active")
	}
}
func (a *CameraAgent) Status() map[string]any {
	return map[string]any{"active": a.active}
}

// ── helpers ───────────────────────────────────────────

func ok(agent string, success bool, value any, unit, sym string) *Result {
	return &Result{Agent: agent, OK: success,
		Value: value, Unit: unit, Symbols: sym, TS: time.Now()}
}

func errResult(agent, msg string) *Result {
	return &Result{Agent: agent, OK: false,
		Symbols: "⊗", TS: time.Now(), Error: msg}
}

func toFloat(v any) (float64, bool) {
	switch x := v.(type) {
	case float64: return x, true
	case int:     return float64(x), true
	case int64:   return float64(x), true
	case string:
		var f float64
		_, err := fmt.Sscanf(x, "%f", &f)
		return f, err == nil
	}
	return 0, false
}

func contains(s, sub string) bool {
	return len(sub) > 0 && len(s) >= len(sub) &&
		(s == sub || len(s) > 0 && containsStr(s, sub))
}

func containsStr(s, sub string) bool {
	for i := 0; i <= len(s)-len(sub); i++ {
		if s[i:i+len(sub)] == sub { return true }
	}
	return false
}
