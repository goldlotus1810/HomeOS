package agents

import (
	"fmt"
	"strings"
	"time"

	"github.com/goldlotus1810/HomeOS/agents/system"
)

// SystemAgent — đọc hardware + quản lý processes
// Mọi action destructive đều cần field "confirmed": true trong Intent
type SystemAgent struct{}

func NewSystemAgent() *SystemAgent { return &SystemAgent{} }

func (a *SystemAgent) Name() string { return "SystemAgent" }

func (a *SystemAgent) CanHandle(i *Intent) bool {
	return i.Agent == "SystemAgent" ||
		i.Chief == "SystemChief" ||
		i.Verb == "SCAN" ||
		i.Verb == "SYSINFO" ||
		containsAny(i.Symbols, "🖥", "💻", "🔍", "⚙")
}

func (a *SystemAgent) Execute(i *Intent) *Result {
	switch i.Verb {

	// SYSINFO — tóm tắt hardware
	case "SYSINFO", "GET":
		summary := system.Summary()
		return ok(a.Name(), true, summary, "", "🖥⩵info⧺✓")

	// SCAN — tìm process chiếm tài nguyên
	case "SCAN":
		procs, err := system.GetProcesses()
		if err != nil {
			return errResult(a.Name(), err.Error())
		}
		suspicious := system.FindSuspicious(procs)
		if len(suspicious) == 0 {
			return ok(a.Name(), true,
				"Không tìm thấy process bất thường. Hệ thống ổn.",
				"", "🔍⩵clean⧺✓")
		}
		// build report
		var lines []string
		for _, s := range suspicious {
			lines = append(lines, fmt.Sprintf(
				"[%d] %s — %s (đề xuất: %s)",
				s.PID, s.Name, s.Reason, s.Action))
		}
		return ok(a.Name(), true,
			map[string]any{
				"suspicious": suspicious,
				"summary":    strings.Join(lines, "\n"),
				"count":      len(suspicious),
			}, "", fmt.Sprintf("🔍⩵%d suspicious", len(suspicious)))

	// KILL — tắt process (BẮT BUỘC confirmed = true)
	case "KILL":
		if !isConfirmed(i) {
			return &Result{
				Agent:   a.Name(),
				OK:      false,
				Symbols: "⊗⧺need_confirm",
				TS:      time.Now(),
				Error:   "KILL cần xác nhận. Set confirmed=true sau khi người dùng đồng ý.",
			}
		}
		pid := toInt(i.Value)
		if pid == 0 {
			return errResult(a.Name(), "cần PID")
		}
		r := system.KillProcess(pid)
		sym := "⊗"; if r.OK { sym = "💀⧺✓" }
		return &Result{Agent: a.Name(), OK: r.OK,
			Value: r.Message, Symbols: sym, TS: time.Now()}

	// STOP — dừng service (BẮT BUỘC confirmed = true)
	case "STOP":
		if !isConfirmed(i) {
			return &Result{Agent: a.Name(), OK: false,
				Symbols: "⊗⧺need_confirm", TS: time.Now(),
				Error: "STOP cần xác nhận."}
		}
		svc := fmt.Sprintf("%v", i.Value)
		r := system.StopService(svc)
		sym := "⊗"; if r.OK { sym = "🛑⧺✓" }
		return &Result{Agent: a.Name(), OK: r.OK,
			Value: r.Message, Symbols: sym, TS: time.Now()}

	// UNINSTALL — gỡ package (BẮT BUỘC confirmed = true)
	case "UNINSTALL":
		if !isConfirmed(i) {
			return &Result{Agent: a.Name(), OK: false,
				Symbols: "⊗⧺need_confirm", TS: time.Now(),
				Error: "UNINSTALL cần xác nhận."}
		}
		pkg := fmt.Sprintf("%v", i.Value)
		r := system.UninstallPackage(pkg)
		sym := "⊗"; if r.OK { sym = "🗑⧺✓" }
		return &Result{Agent: a.Name(), OK: r.OK,
			Value: r.Message, Symbols: sym, TS: time.Now()}
	}

	return errResult(a.Name(), "unknown verb: "+i.Verb)
}

func (a *SystemAgent) Status() map[string]any {
	h, _ := system.GetHardware()
	if h == nil { return map[string]any{"ok": false} }
	return map[string]any{
		"cpu_pct": h.CPU.UsagePct,
		"mem_pct": h.Memory.UsePct,
		"load1":   h.Load.Load1,
		"uptime":  h.Uptime,
	}
}

// ── helpers ───────────────────────────────────────────

func isConfirmed(i *Intent) bool {
	if i.Value == nil { return false }
	if m, ok := i.Value.(map[string]any); ok {
		if v, ok2 := m["confirmed"]; ok2 {
			if b, ok3 := v.(bool); ok3 { return b }
		}
	}
	return false
}

func toInt(v any) int {
	switch x := v.(type) {
	case int:     return x
	case int64:   return int(x)
	case float64: return int(x)
	}
	return 0
}

func containsAny(s string, subs ...string) bool {
	for _, sub := range subs {
		if strings.Contains(s, sub) { return true }
	}
	return false
}
