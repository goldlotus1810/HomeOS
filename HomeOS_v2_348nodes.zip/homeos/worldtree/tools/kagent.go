// Package tools — KAgent: query engine trên KStore
// Verbs: KNOW SEARCH NEAR LANG RELATE UNION STATS DANGER
// Format: KIntent → KResult

package tools

import (
	"fmt"
	"strings"
)

// ── Intent / Result ───────────────────────────────────

type KIntent struct {
	Verb  string   // KNOW SEARCH NEAR LANG RELATE UNION STATS DANGER
	Query string   // text query
	SDF   [3]float64 // cho NEAR
	Limit int
	Depth int // cho RELATE (graph depth)
}

type KResult struct {
	OK    bool
	Nodes []KNode
	Stats map[string]any
	Error string
	Verb  string
}

// KAgent — wraps KStore với intent-based API
type KAgent struct {
	store *KStore
}

func NewKAgent(worldtreeDir string) (*KAgent, error) {
	ks, err := NewKStore(worldtreeDir)
	if err != nil {
		return nil, fmt.Errorf("kagent: %w", err)
	}
	return &KAgent{store: ks}, nil
}

func NewKAgentFromStore(ks *KStore) *KAgent {
	return &KAgent{store: ks}
}

// Execute — dispatch intent → kết quả
func (ka *KAgent) Execute(intent KIntent) KResult {
	limit := intent.Limit
	if limit <= 0 {
		limit = 5
	}
	depth := intent.Depth
	if depth <= 0 {
		depth = 2
	}

	switch strings.ToUpper(intent.Verb) {

	// KNOW — tìm chính xác theo tên
	case "KNOW":
		node, ok := ka.store.Get(intent.Query)
		if !ok {
			// fallback: search
			res := ka.store.Search(intent.Query, 1)
			if len(res) == 0 {
				return KResult{OK: false, Verb: "KNOW",
					Error: fmt.Sprintf("không tìm thấy: %q", intent.Query)}
			}
			return KResult{OK: true, Nodes: res, Verb: "KNOW"}
		}
		return KResult{OK: true, Nodes: []KNode{*node}, Verb: "KNOW"}

	// SEARCH — full-text search
	case "SEARCH":
		nodes := ka.store.Search(intent.Query, limit)
		if len(nodes) == 0 {
			return KResult{OK: false, Verb: "SEARCH",
				Error: fmt.Sprintf("không có kết quả cho: %q", intent.Query)}
		}
		return KResult{OK: true, Nodes: nodes, Verb: "SEARCH"}

	// NEAR — tìm node gần nhất trong SDF space
	case "NEAR":
		sdf := intent.SDF
		if sdf == ([3]float64{}) && intent.Query != "" {
			// ước lượng SDF từ text
			sdf = SDFFromText(intent.Query)
		}
		nodes := ka.store.Nearest(sdf, limit)
		return KResult{OK: true, Nodes: nodes, Verb: "NEAR"}

	// LANG — tìm tất cả concepts của 1 ngôn ngữ
	case "LANG":
		nodes := ka.store.QueryLang(intent.Query)
		if len(nodes) == 0 {
			return KResult{OK: false, Verb: "LANG",
				Error: fmt.Sprintf("không có nodes cho ngôn ngữ: %q", intent.Query)}
		}
		if len(nodes) > limit {
			nodes = nodes[:limit]
		}
		return KResult{OK: true, Nodes: nodes, Verb: "LANG"}

	// RELATE — graph traversal từ 1 node
	case "RELATE":
		nodes := ka.store.Relate(intent.Query, depth)
		if len(nodes) == 0 {
			return KResult{OK: false, Verb: "RELATE",
				Error: fmt.Sprintf("không có related nodes cho: %q", intent.Query)}
		}
		return KResult{OK: true, Nodes: nodes, Verb: "RELATE"}

	// UNION — smooth union của nhiều queries (SDF blend)
	case "UNION":
		queries := strings.Split(intent.Query, ",")
		for i := range queries {
			queries[i] = strings.TrimSpace(queries[i])
		}
		nodes := ka.store.SmoothUnion(queries, limit)
		return KResult{OK: true, Nodes: nodes, Verb: "UNION"}

	// STATS — thống kê kho
	case "STATS":
		stats := ka.store.Stats()
		return KResult{OK: true, Stats: stats, Verb: "STATS"}

	// DANGER — tìm nodes có warning nguy hiểm
	case "DANGER":
		nodes := ka.store.DangerNodes(intent.Query, limit)
		if len(nodes) == 0 {
			return KResult{OK: true, Nodes: []KNode{}, Verb: "DANGER",
				Error: "không có danger nodes cho query này"}
		}
		return KResult{OK: true, Nodes: nodes, Verb: "DANGER"}

	// ALL — dump toàn bộ (dùng cho debug)
	case "ALL":
		all := ka.store.All()
		if len(all) > limit*10 {
			all = all[:limit*10]
		}
		return KResult{OK: true, Nodes: all, Verb: "ALL",
			Stats: map[string]any{"total": ka.store.Count()}}

	default:
		return KResult{OK: false, Verb: intent.Verb,
			Error: fmt.Sprintf("unknown verb: %q (KNOW|SEARCH|NEAR|LANG|RELATE|UNION|STATS|DANGER)", intent.Verb)}
	}
}

// Store — trả về KStore để gọi AddLearnedNode
func (ka *KAgent) Store() *KStore {
	return ka.store
}

// Count — số nodes trong store
func (ka *KAgent) Count() int {
	return ka.store.Count()
}

// FormatResult — format KResult thành text dễ đọc cho AAM
func FormatResult(r KResult) string {
	if !r.OK && len(r.Nodes) == 0 {
		return "○ " + r.Error
	}

	var sb strings.Builder

	if r.Verb == "STATS" {
		sb.WriteString("○ WORLDTREE stats:\n")
		if r.Stats != nil {
			if total, ok := r.Stats["total"]; ok {
				sb.WriteString(fmt.Sprintf("  nodes: %v\n", total))
			}
			if bl, ok := r.Stats["by_layer"].(map[int]int); ok {
				sb.WriteString("  layers: ")
				for l := 1; l <= 7; l++ {
					if n, ok := bl[l]; ok {
						sb.WriteString(fmt.Sprintf("L%d=%d ", l, n))
					}
				}
				sb.WriteString("\n")
			}
			if dn, ok := r.Stats["danger_nodes"]; ok {
				sb.WriteString(fmt.Sprintf("  danger: %v nodes\n", dn))
			}
		}
		return sb.String()
	}

	for i, n := range r.Nodes {
		if i >= 5 {
			sb.WriteString(fmt.Sprintf("  … và %d nodes khác\n", len(r.Nodes)-5))
			break
		}
		sym := n.Sym
		if sym == "" {
			sym = "○"
		}
		sb.WriteString(fmt.Sprintf("%s **%s**\n", sym, n.Name))
		if n.Summary != "" {
			sb.WriteString(fmt.Sprintf("  %s\n", n.Summary))
		}
		if len(n.ExistsIn) > 0 {
			sb.WriteString(fmt.Sprintf("  Có trong: %s\n", strings.Join(n.ExistsIn, ", ")))
		}
		if len(n.Danger) > 0 {
			sb.WriteString(fmt.Sprintf("  ⚠ %s\n", n.Danger[0]))
		}
		if i < len(r.Nodes)-1 {
			sb.WriteString("\n")
		}
	}
	return sb.String()
}
