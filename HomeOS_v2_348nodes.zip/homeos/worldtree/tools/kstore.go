// Package tools — KStore: in-memory knowledge store cho ○ WORLDTREE
// Load L1-L7 + learned/prog/*.○node.json → RAM
// Query: SDF distance, text search, graph traverse, smooth union
// Append-only: không xóa, không sửa — chỉ thêm node mới

package tools

import (
	"encoding/json"
	"fmt"
	"io/fs"
	"math"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
)

// ── KNode ─────────────────────────────────────────────
// Hỗ trợ cả 2 format:
//   L*/*.json  : sym, NOT_in
//   ○node.json : symbol, not_in

type KNode struct {
	Name     string     `json:"name"`
	Sym      string     `json:"sym"`     // L* format
	Symbol   string     `json:"symbol"`  // ○ format
	SDF      [3]float64 `json:"sdf"`
	ISL      [4]int     `json:"isl"`
	Summary  string     `json:"summary"`
	Layer    int        `json:"layer,omitempty"`
	Category string     `json:"category,omitempty"`
	ExistsIn []string   `json:"exists_in,omitempty"`
	NotIn    []string   `json:"NOT_in,omitempty"` // L* format
	NotIn2   []string   `json:"not_in,omitempty"` // ○ format
	Related  []string   `json:"related,omitempty"`
	Tags     []string   `json:"tags,omitempty"`
	Danger   []string   `json:"danger,omitempty"`
	Facts    []struct {
		Sym  string `json:"sym"`
		Text string `json:"text"`
	} `json:"facts,omitempty"`
	Concepts []KNode `json:"concepts,omitempty"`
	Source   string  `json:"_source,omitempty"`
}

// normalize — sau unmarshal, hợp nhất fields tương đương
func (n *KNode) normalize() {
	if n.Sym == "" && n.Symbol != "" {
		n.Sym = n.Symbol
	}
	if n.Symbol == "" && n.Sym != "" {
		n.Symbol = n.Sym
	}
	if len(n.NotIn) == 0 && len(n.NotIn2) > 0 {
		n.NotIn = n.NotIn2
	}
	// auto-extract danger từ facts nếu còn trống
	if len(n.Danger) == 0 && len(n.Facts) > 0 {
		kws := []string{
			"undefined behavior", "UB", "segfault", "overflow",
			"data race", "deadlock", "null deref", "injection",
			"XSS", "buffer overflow", "dangling", "memory leak",
			"stack overflow", "panic", "crash", "double free",
		}
		for _, f := range n.Facts {
			combined := strings.ToLower(f.Sym + " " + f.Text)
			for _, kw := range kws {
				if strings.Contains(combined, strings.ToLower(kw)) {
					entry := f.Text
					if f.Sym != "" {
						entry = f.Sym + ": " + f.Text
					}
					n.Danger = append(n.Danger, entry)
					break
				}
			}
		}
	}
}

// KFile — format của L*/*.json
type KFile struct {
	Layer       int     `json:"layer"`
	Name        string  `json:"name"`
	Description string  `json:"description"`
	Nodes       []KNode `json:"nodes"`
}

// ── KStore ────────────────────────────────────────────

type KStore struct {
	mu    sync.RWMutex
	nodes []KNode
	index map[string]*KNode // name(lower) → node
	root  string
}

func NewKStore(root string) (*KStore, error) {
	ks := &KStore{
		root:  root,
		index: make(map[string]*KNode),
	}
	if err := ks.load(); err != nil {
		return nil, err
	}
	return ks, nil
}

func (ks *KStore) load() error {
	ks.mu.Lock()
	defer ks.mu.Unlock()

	var files []string

	// 1. L*_*/*.json — layer files
	layerPattern := filepath.Join(ks.root, "L*", "*.json")
	lf, _ := filepath.Glob(layerPattern)
	files = append(files, lf...)

	// 2. learned/**/*.○node.json — đệ quy
	learnedRoot := filepath.Join(ks.root, "learned")
	filepath.WalkDir(learnedRoot, func(path string, d fs.DirEntry, err error) error {
		if err != nil {
			return nil
		}
		if !d.IsDir() && strings.HasSuffix(d.Name(), ".○node.json") {
			files = append(files, path)
		}
		return nil
	})

	loaded := 0
	for _, fpath := range files {
		if err := ks.loadFile(fpath); err != nil {
			fmt.Fprintf(os.Stderr, "kstore: skip %s: %v\n", fpath, err)
			continue
		}
		loaded++
	}
	fmt.Fprintf(os.Stderr, "kstore: loaded %d files → %d nodes\n", loaded, len(ks.nodes))
	return nil
}

func (ks *KStore) loadFile(fpath string) error {
	data, err := os.ReadFile(fpath)
	if err != nil {
		return err
	}

	// Thử KFile (layer format)
	var kf KFile
	if err := json.Unmarshal(data, &kf); err == nil && kf.Layer > 0 && len(kf.Nodes) > 0 {
		for i := range kf.Nodes {
			n := &kf.Nodes[i]
			n.Layer = kf.Layer
			n.Source = fpath
			ks.addNode(n)
			for j := range n.Concepts {
				c := &n.Concepts[j]
				c.Layer = kf.Layer
				c.Source = fpath
				if c.ExistsIn == nil {
					c.ExistsIn = n.ExistsIn
				}
				ks.addNode(c)
			}
		}
		return nil
	}

	// Thử single KNode (○ format)
	var kn KNode
	if err := json.Unmarshal(data, &kn); err == nil && kn.Name != "" {
		kn.Source = fpath
		ks.addNode(&kn)
		return nil
	}

	return fmt.Errorf("unrecognized format")
}

func (ks *KStore) addNode(n *KNode) {
	n.normalize()
	// Tránh duplicate: nếu đã có node cùng tên, dùng bản mới (learned ưu tiên hơn L*)
	lower := strings.ToLower(n.Name)
	if existing, ok := ks.index[lower]; ok {
		// Update in place nếu bản mới có nhiều data hơn
		if len(n.Facts) > len(existing.Facts) || len(n.Related) > len(existing.Related) {
			*existing = *n
		}
		return
	}
	ks.nodes = append(ks.nodes, *n)
	ptr := &ks.nodes[len(ks.nodes)-1]
	ks.index[lower] = ptr
	if n.Name != lower {
		ks.index[n.Name] = ptr
	}
}

// AddLearnedNode — thêm node mới được học tại runtime (append-only)
func (ks *KStore) AddLearnedNode(n *KNode) {
	ks.mu.Lock()
	defer ks.mu.Unlock()
	n.Source = "runtime_learned"
	ks.addNode(n)
}

// ── Queries ───────────────────────────────────────────

func (ks *KStore) Get(name string) (*KNode, bool) {
	ks.mu.RLock()
	defer ks.mu.RUnlock()
	n, ok := ks.index[strings.ToLower(name)]
	return n, ok
}

func (ks *KStore) Search(query string, limit int) []KNode {
	ks.mu.RLock()
	defer ks.mu.RUnlock()

	q := strings.ToLower(query)
	words := strings.Fields(q)

	type scored struct {
		node  KNode
		score float64
	}
	var results []scored

	for _, n := range ks.nodes {
		score := 0.0
		nameLower := strings.ToLower(n.Name)
		summLower := strings.ToLower(n.Summary)

		for _, w := range words {
			if strings.Contains(nameLower, w) {
				score += 3.0
			}
			if strings.Contains(summLower, w) {
				score += 1.0
			}
			for _, tag := range n.Tags {
				if strings.Contains(strings.ToLower(tag), w) {
					score += 2.0
				}
			}
			for _, lang := range n.ExistsIn {
				if strings.Contains(strings.ToLower(lang), w) {
					score += 1.5
				}
			}
		}
		if score > 0 {
			results = append(results, scored{n, score})
		}
	}

	sort.Slice(results, func(i, j int) bool {
		return results[i].score > results[j].score
	})

	if limit <= 0 || limit > len(results) {
		limit = len(results)
	}
	out := make([]KNode, limit)
	for i := range out {
		out[i] = results[i].node
	}
	return out
}

func (ks *KStore) Nearest(sdf [3]float64, limit int) []KNode {
	ks.mu.RLock()
	defer ks.mu.RUnlock()

	type dist struct {
		node KNode
		d    float64
	}
	var dists []dist
	for _, n := range ks.nodes {
		dists = append(dists, dist{n, sdfDist(sdf, n.SDF)})
	}
	sort.Slice(dists, func(i, j int) bool {
		return dists[i].d < dists[j].d
	})
	if limit <= 0 || limit > len(dists) {
		limit = len(dists)
	}
	out := make([]KNode, limit)
	for i := range out {
		out[i] = dists[i].node
	}
	return out
}

func (ks *KStore) Relate(name string, depth int) []KNode {
	ks.mu.RLock()
	defer ks.mu.RUnlock()

	seen := map[string]bool{strings.ToLower(name): true}
	var result []KNode
	queue := []string{name}

	for d := 0; d < depth && len(queue) > 0; d++ {
		var next []string
		for _, n := range queue {
			node, ok := ks.index[strings.ToLower(n)]
			if !ok {
				continue
			}
			for _, rel := range node.Related {
				relLower := strings.ToLower(rel)
				if seen[relLower] {
					continue
				}
				seen[relLower] = true
				if rn, ok := ks.index[relLower]; ok {
					result = append(result, *rn)
					next = append(next, rel)
				}
			}
		}
		queue = next
	}
	return result
}

func (ks *KStore) QueryLang(lang string) []KNode {
	ks.mu.RLock()
	defer ks.mu.RUnlock()

	langLower := strings.ToLower(lang)
	var result []KNode
	for _, n := range ks.nodes {
		for _, l := range n.ExistsIn {
			if strings.Contains(strings.ToLower(l), langLower) {
				result = append(result, n)
				break
			}
		}
	}
	return result
}

func (ks *KStore) SmoothUnion(queries []string, limit int) []KNode {
	var found []KNode
	for _, q := range queries {
		if n, ok := ks.Get(q); ok {
			found = append(found, *n)
		} else {
			res := ks.Search(q, 1)
			if len(res) > 0 {
				found = append(found, res[0])
			}
		}
	}
	if len(found) == 0 {
		return ks.Search(strings.Join(queries, " "), limit)
	}
	center := Centroid(found)
	return ks.Nearest(center, limit)
}

func (ks *KStore) DangerNodes(query string, limit int) []KNode {
	ks.mu.RLock()
	defer ks.mu.RUnlock()

	q := strings.ToLower(query)
	var result []KNode
	for _, n := range ks.nodes {
		if len(n.Danger) == 0 {
			continue
		}
		if q == "" ||
			strings.Contains(strings.ToLower(n.Name), q) ||
			strings.Contains(strings.ToLower(n.Summary), q) {
			result = append(result, n)
		}
	}
	if limit > 0 && limit < len(result) {
		result = result[:limit]
	}
	return result
}

func (ks *KStore) Stats() map[string]any {
	ks.mu.RLock()
	defer ks.mu.RUnlock()

	byLayer := map[int]int{}
	byLang := map[string]int{}
	dangerCount := 0
	for _, n := range ks.nodes {
		byLayer[n.Layer]++
		for _, l := range n.ExistsIn {
			byLang[l]++
		}
		if len(n.Danger) > 0 {
			dangerCount++
		}
	}
	return map[string]any{
		"total":        len(ks.nodes),
		"by_layer":     byLayer,
		"by_lang":      byLang,
		"danger_nodes": dangerCount,
		"root":         ks.root,
	}
}

func (ks *KStore) All() []KNode {
	ks.mu.RLock()
	defer ks.mu.RUnlock()
	out := make([]KNode, len(ks.nodes))
	copy(out, ks.nodes)
	return out
}

func (ks *KStore) Count() int {
	ks.mu.RLock()
	defer ks.mu.RUnlock()
	return len(ks.nodes)
}

// ── Helpers ───────────────────────────────────────────

func sdfDist(a, b [3]float64) float64 {
	dx, dy, dz := a[0]-b[0], a[1]-b[1], a[2]-b[2]
	return math.Sqrt(dx*dx + dy*dy + dz*dz)
}

func Centroid(nodes []KNode) [3]float64 {
	if len(nodes) == 0 {
		return [3]float64{}
	}
	var sum [3]float64
	for _, n := range nodes {
		sum[0] += n.SDF[0]
		sum[1] += n.SDF[1]
		sum[2] += n.SDF[2]
	}
	f := float64(len(nodes))
	return [3]float64{sum[0] / f, sum[1] / f, sum[2] / f}
}

// SDFFromText — ước lượng SDF từ text (heuristic, không cần exact node)
func SDFFromText(text string) [3]float64 {
	t := strings.ToLower(text)
	x, y, z := 0.0, 0.0, 0.0

	// X: abstraction (-1=hardware, +1=declarative)
	for _, w := range []string{"assembly", "register", "opcode", "bit", "byte", "pointer", "malloc", "cpu", "hardware", "cache", "simd"} {
		if strings.Contains(t, w) {
			x -= 0.3
		}
	}
	for _, w := range []string{"python", "javascript", "ruby", "sql", "html", "declarative", "framework", "api", "rest", "yaml"} {
		if strings.Contains(t, w) {
			x += 0.3
		}
	}

	// Y: safety (-1=manual, +1=managed)
	for _, w := range []string{"unsafe", "undefined behavior", "null", "dangling", "overflow", "segfault", "malloc", "free"} {
		if strings.Contains(t, w) {
			y -= 0.3
		}
	}
	for _, w := range []string{"rust", "ownership", "borrow", "lifetime", "option", "result", "gc", "garbage", "safe", "checked"} {
		if strings.Contains(t, w) {
			y += 0.3
		}
	}

	// Z: paradigm (-1=imperative, +1=functional)
	for _, w := range []string{"for", "while", "loop", "mutation", "state", "imperative", "assign", "goto"} {
		if strings.Contains(t, w) {
			z -= 0.2
		}
	}
	for _, w := range []string{"functional", "lambda", "closure", "pure", "immutable", "monad", "haskell", "fold", "map", "filter"} {
		if strings.Contains(t, w) {
			z += 0.2
		}
	}

	clamp := func(v float64) float64 {
		if v < -1 {
			return -1
		}
		if v > 1 {
			return 1
		}
		return v
	}
	return [3]float64{clamp(x), clamp(y), clamp(z)}
}
