#!/usr/bin/env bash
# HomeOS installer — ArchLinux
# Cài đặt: hotkey (Super+Space) + browser keyword "aam"
# Chạy: chmod +x install.sh && ./install.sh

set -e
HOMEOS_DIR="$(cd "$(dirname "$0")" && pwd)"
HOMEOS_PORT="${HOMEOS_PORT:-8080}"

GREEN='\033[0;32m' YELLOW='\033[1;33m' RED='\033[0;31m' NC='\033[0m'
ok()   { echo -e "${GREEN}✓${NC} $1"; }
warn() { echo -e "${YELLOW}⚠${NC} $1"; }
err()  { echo -e "${RED}✗${NC} $1"; }

echo ""
echo "  ○ HomeOS installer — ArchLinux"
echo "  ──────────────────────────────"
echo ""

# ── 1. Build HomeOS binary ────────────────────────────
echo "→ Build HomeOS..."
if ! command -v go &>/dev/null; then
  warn "Go chưa cài. Cài bằng: sudo pacman -S go"
  exit 1
fi

cd "$HOMEOS_DIR"
go build -o homeos . || { err "Build thất bại"; exit 1; }
ok "Build thành công: $HOMEOS_DIR/homeos"

# ── 2. Systemd user service ───────────────────────────
echo ""
echo "→ Cài systemd service..."

SERVICE_DIR="$HOME/.config/systemd/user"
mkdir -p "$SERVICE_DIR"

cat > "$SERVICE_DIR/homeos.service" << EOF
[Unit]
Description=HomeOS local server
After=network.target

[Service]
Type=simple
WorkingDirectory=${HOMEOS_DIR}
ExecStart=${HOMEOS_DIR}/homeos
Restart=on-failure
RestartSec=3
Environment=HOMEOS_PORT=${HOMEOS_PORT}
Environment=HOMEOS_STATIC=${HOMEOS_DIR}/static
Environment=HOMEOS_LEDGER=${HOMEOS_DIR}/ledger.jsonl
# Thêm API key của bạn vào đây:
# Environment=ANTHROPIC_API_KEY=sk-ant-...
# Hoặc tạo file: ~/.config/homeos/env
EnvironmentFile=-%{h}/.config/homeos/env

[Install]
WantedBy=default.target
EOF

systemctl --user daemon-reload
systemctl --user enable homeos
systemctl --user start homeos
ok "HomeOS service đã chạy (port $HOMEOS_PORT)"

# ── 3. Tạo file env ───────────────────────────────────
mkdir -p "$HOME/.config/homeos"
ENV_FILE="$HOME/.config/homeos/env"
if [ ! -f "$ENV_FILE" ]; then
  cat > "$ENV_FILE" << 'EOF'
# HomeOS environment
# Thêm API key của bạn:
# ANTHROPIC_API_KEY=sk-ant-...
EOF
  ok "Tạo $ENV_FILE — thêm ANTHROPIC_API_KEY vào đây"
else
  ok "$ENV_FILE đã tồn tại"
fi

# ── 4. Script gọi popup ───────────────────────────────
echo ""
echo "→ Tạo aam-popup script..."

POPUP_SCRIPT="$HOME/.local/bin/aam-popup"
mkdir -p "$HOME/.local/bin"

cat > "$POPUP_SCRIPT" << EOF
#!/usr/bin/env bash
# Mở AAM popup trong cửa sổ nhỏ
# Gọi từ hotkey hoặc terminal: aam-popup

URL="http://localhost:${HOMEOS_PORT}/popup.html"

# Thử theo thứ tự: xdg-open với chromium flags, firefox popup, fallback
if command -v chromium &>/dev/null; then
  chromium --app="\$URL" \\
    --window-size=640,520 \\
    --window-position=800,200 \\
    --no-first-run \\
    --disable-infobars \\
    --disable-extensions \\
    &
elif command -v chromium-browser &>/dev/null; then
  chromium-browser --app="\$URL" \\
    --window-size=640,520 \\
    --window-position=800,200 &
elif command -v google-chrome &>/dev/null; then
  google-chrome --app="\$URL" \\
    --window-size=640,520 \\
    --window-position=800,200 &
elif command -v firefox &>/dev/null; then
  firefox --new-window "\$URL" &
else
  xdg-open "\$URL"
fi
EOF

chmod +x "$POPUP_SCRIPT"
ok "Tạo $POPUP_SCRIPT"

# ── 5. Hotkey — xbindkeys hoặc i3/sway ───────────────
echo ""
echo "→ Cài hotkey..."

setup_xbindkeys() {
  if ! command -v xbindkeys &>/dev/null; then
    warn "xbindkeys chưa cài. Cài: sudo pacman -S xbindkeys"
    return
  fi
  XBIND_FILE="$HOME/.xbindkeysrc"
  HOTKEY_LINE='"$HOME/.local/bin/aam-popup"'
  HOTKEY_BIND="  Mod4+space"
  if ! grep -q "aam-popup" "$XBIND_FILE" 2>/dev/null; then
    echo "" >> "$XBIND_FILE"
    echo "# HomeOS AAM" >> "$XBIND_FILE"
    echo "$HOTKEY_LINE" >> "$XBIND_FILE"
    echo "$HOTKEY_BIND" >> "$XBIND_FILE"
    pkill -HUP xbindkeys 2>/dev/null || xbindkeys &
    ok "xbindkeys: Super+Space → aam-popup"
  else
    ok "xbindkeys đã có aam-popup"
  fi
}

setup_i3() {
  I3_CONFIG="$HOME/.config/i3/config"
  if [ -f "$I3_CONFIG" ] && ! grep -q "aam-popup" "$I3_CONFIG"; then
    echo "" >> "$I3_CONFIG"
    echo "# HomeOS AAM" >> "$I3_CONFIG"
    echo "bindsym \$mod+space exec --no-startup-id $POPUP_SCRIPT" >> "$I3_CONFIG"
    ok "i3: Mod+Space → aam-popup (reload i3 để áp dụng)"
  fi
}

setup_sway() {
  SWAY_CONFIG="$HOME/.config/sway/config"
  if [ -f "$SWAY_CONFIG" ] && ! grep -q "aam-popup" "$SWAY_CONFIG"; then
    echo "" >> "$SWAY_CONFIG"
    echo "# HomeOS AAM" >> "$SWAY_CONFIG"
    echo "bindsym \$mod+space exec $POPUP_SCRIPT" >> "$SWAY_CONFIG"
    ok "sway: Mod+Space → aam-popup (reload sway để áp dụng)"
  fi
}

setup_hyprland() {
  HYPR_CONFIG="$HOME/.config/hypr/hyprland.conf"
  if [ -f "$HYPR_CONFIG" ] && ! grep -q "aam-popup" "$HYPR_CONFIG"; then
    echo "" >> "$HYPR_CONFIG"
    echo "# HomeOS AAM" >> "$HYPR_CONFIG"
    echo "bind = SUPER, SPACE, exec, $POPUP_SCRIPT" >> "$HYPR_CONFIG"
    ok "hyprland: Super+Space → aam-popup"
  fi
}

# detect WM
if [ -n "$I3SOCK" ]; then
  setup_i3
elif [ -n "$SWAYSOCK" ]; then
  setup_sway
elif pgrep -x hyprland &>/dev/null; then
  setup_hyprland
else
  setup_xbindkeys
fi

# ── 6. Browser keyword "aam" ──────────────────────────
echo ""
echo "→ Cài browser keyword..."

# Chromium/Chrome: tạo search engine keyword
CHROM_DIRS=(
  "$HOME/.config/chromium/Default"
  "$HOME/.config/google-chrome/Default"
  "$HOME/.config/chromium-browser/Default"
)

for DIR in "${CHROM_DIRS[@]}"; do
  if [ -d "$DIR" ]; then
    warn "Chromium/Chrome: vào Settings → Search engines → Add"
    warn "  Name: AAM    Keyword: aam    URL: http://localhost:${HOMEOS_PORT}/popup.html"
    break
  fi
done

# Firefox: cài keyword qua bookmarks
if command -v firefox &>/dev/null; then
  warn "Firefox: Bookmarks → New Bookmark"
  warn "  Name: AAM    Keyword: aam    URL: http://localhost:${HOMEOS_PORT}/popup.html"
fi

# ── 7. Desktop file (rofi / dmenu) ───────────────────
DESKTOP_FILE="$HOME/.local/share/applications/homeos-aam.desktop"
mkdir -p "$HOME/.local/share/applications"
cat > "$DESKTOP_FILE" << EOF
[Desktop Entry]
Type=Application
Name=AAM — HomeOS
Comment=HomeOS Agent AI Master
Exec=${POPUP_SCRIPT}
Icon=utilities-terminal
Categories=Utility;
Keywords=aam;homeos;smart home;
EOF
ok "Desktop entry tạo xong (rofi/dmenu sẽ thấy 'AAM')"

# ── 8. Done ───────────────────────────────────────────
echo ""
echo -e "${GREEN}  ○ HomeOS đã cài xong!${NC}"
echo ""
echo "  Cách gọi AAM:"
echo "  1. Hotkey: Super+Space"
echo "  2. Browser address bar: gõ 'aam' → Enter"
echo "     (cần thêm keyword trong browser settings)"
echo "  3. Terminal: aam-popup"
echo "  4. Rofi/dmenu: tìm 'AAM'"
echo ""
echo "  Thêm API key:"
echo "  echo 'ANTHROPIC_API_KEY=sk-ant-...' >> ~/.config/homeos/env"
echo "  systemctl --user restart homeos"
echo ""
echo "  Xem log:"
echo "  journalctl --user -u homeos -f"
echo ""
