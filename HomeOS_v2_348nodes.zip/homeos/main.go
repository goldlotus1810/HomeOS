package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"time"

	"github.com/goldlotus1810/HomeOS/aam"
	"github.com/goldlotus1810/HomeOS/agents"
	"github.com/goldlotus1810/HomeOS/ledger"
	"github.com/goldlotus1810/HomeOS/worldtree/tools"
)

func main() {
	port         := envOr("HOMEOS_PORT",      "8080")
	ledgerPath   := envOr("HOMEOS_LEDGER",    "ledger.jsonl")
	staticDir    := envOr("HOMEOS_STATIC",    "static")
	worldtreeDir := envOr("HOMEOS_WORLDTREE", "WORLDTREE")
	claudeKey    := os.Getenv("ANTHROPIC_API_KEY")

	lg, err := ledger.Open(ledgerPath)
	if err != nil { log.Fatalf("ledger: %v", err) }
	defer lg.Close()

	// AAM — với WorldtreeDir để check ○ trước Claude
	a := aam.New(aam.Config{
		ClaudeAPIKey: claudeKey,
		Ledger:       lg,
		AskThreshold: 0.72,
		WorldtreeDir: worldtreeDir,
	})

	// Agent bus
	bus := agents.NewBus()
	bus.Register(agents.NewLightAgent())
	bus.Register(agents.NewHVACAgent())
	bus.Register(agents.NewLockAgent())
	bus.Register(agents.NewBatteryAgent())
	bus.Register(agents.NewCameraAgent())
	bus.Register(agents.NewSystemAgent())

	// WebAgent
	os.MkdirAll(worldtreeDir, 0755)
	webAgent, err := agents.NewWebAgent(claudeKey, worldtreeDir)
	if err != nil {
		log.Printf("webagent: %v", err)
	} else {
		bus.Register(webAgent)
	}

	// KnowledgeAgent — đăng ký trong bus
	var kAgentStore *tools.KAgent
	if ka, err := agents.NewKnowledgeAgent(worldtreeDir); err != nil {
		log.Printf("knowledge agent: %v (tiếp tục không có ○ agent)", err)
	} else {
		bus.Register(ka)
		kAgentStore = ka.KAgent()
		log.Printf("○ KnowledgeAgent: %d nodes", ka.KAgent().Count())
	}

	mux := http.NewServeMux()
	mux.Handle("/", http.FileServer(http.Dir(staticDir)))

	// /api/chat — main chat endpoint
	mux.HandleFunc("/api/chat", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost { http.Error(w, "405", 405); return }
		var req struct {
			Text    string `json:"text"`
			Session string `json:"session"`
		}
		json.NewDecoder(r.Body).Decode(&req)

		resp, err := a.Process(r.Context(), req.Text, req.Session)
		if err != nil { writeJSON(w, 500, map[string]string{"error": err.Error()}); return }

		var agentResult *agents.Result
		if resp.Intent != nil {
			agentResult, _ = bus.Execute(&agents.Intent{
				Verb: resp.Intent.Verb, Chief: resp.Intent.Chief,
				Agent: resp.Intent.Agent, Target: resp.Intent.Target,
				Value: resp.Intent.Value, Unit: resp.Intent.Unit,
				Symbols: resp.Intent.Symbols,
			})
		}

		writeJSON(w, 200, map[string]any{
			"reply":          resp.Reply,
			"intent":         resp.Intent,
			"agent":          agentResult,
			"learned":        resp.Learned,
			"asked_claude":   resp.AskedClaude,
			"from_worldtree": resp.FromWorldtree,
			"confidence":     resp.Confidence,
			"from_ledger":    resp.FromLedger,
			"ts":             time.Now().UnixMilli(),
		})
	})

	// /api/knowledge — query ○ trực tiếp
	mux.HandleFunc("/api/knowledge", func(w http.ResponseWriter, r *http.Request) {
		if kAgentStore == nil {
			writeJSON(w, 503, map[string]string{"error": "KnowledgeAgent không khởi động được"})
			return
		}
		verb  := r.URL.Query().Get("verb")
		query := r.URL.Query().Get("q")
		if verb == "" { verb = "SEARCH" }

		result := kAgentStore.Execute(tools.KIntent{
			Verb:  verb,
			Query: query,
			Limit: 10,
			Depth: 2,
		})
		writeJSON(w, 200, map[string]any{
			"ok":    result.OK,
			"verb":  result.Verb,
			"nodes": result.Nodes,
			"stats": result.Stats,
			"error": result.Error,
			"count": len(result.Nodes),
		})
	})

	// /api/ledger
	mux.HandleFunc("/api/ledger", func(w http.ResponseWriter, r *http.Request) {
		e, _ := lg.Recent(50)
		writeJSON(w, 200, e)
	})

	// /api/agents
	mux.HandleFunc("/api/agents", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, 200, bus.Status())
	})

	// /api/worldtree — list learned nodes từ WebAgent
	mux.HandleFunc("/api/worldtree", func(w http.ResponseWriter, r *http.Request) {
		if webAgent == nil {
			writeJSON(w, 503, map[string]string{"error": "no webagent"})
			return
		}
		result, _ := bus.Execute(&agents.Intent{Verb: "LIST", Agent: "WebAgent"})
		writeJSON(w, 200, result)
	})

	// /api/health
	mux.HandleFunc("/api/health", func(w http.ResponseWriter, r *http.Request) {
		webNodes := 0
		if webAgent != nil { webNodes = webAgent.LearnedCount() }
		kNodes := 0
		if kAgentStore != nil { kNodes = kAgentStore.Count() }
		writeJSON(w, 200, map[string]any{
			"status":   "ok",
			"version":  "HomeOS v2 · ○ WORLDTREE · SILK v1",
			"agents":   bus.Count(),
			"learned":  lg.Count(),
			"nodes_web": webNodes,
			"nodes_○":  kNodes,
			"ts":       time.Now().UnixMilli(),
		})
	})

	log.Printf("○ HomeOS  http://localhost:%s  agents=%d  worldtree=%s",
		port, bus.Count(), worldtreeDir)
	if claudeKey == "" { log.Printf("  ⚠ ANTHROPIC_API_KEY not set") }

	srv := &http.Server{
		Addr:         ":" + port,
		Handler:      cors(mux),
		ReadTimeout:  30 * time.Second,
		WriteTimeout: 90 * time.Second,
	}
	log.Fatal(srv.ListenAndServe())
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(v)
}

func cors(h http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type")
		if r.Method == "OPTIONS" { w.WriteHeader(204); return }
		h.ServeHTTP(w, r)
	})
}

func envOr(key, def string) string {
	if v := os.Getenv(key); v != "" { return filepath.Clean(v) }
	return def
}

func init() { fmt.Println("  ○ HomeOS v2 · SILK · WebAgent · ○ WORLDTREE") }
