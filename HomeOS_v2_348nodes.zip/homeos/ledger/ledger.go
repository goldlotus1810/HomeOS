// Package ledger — append-only learning log
// QT7: Học = chỉ thêm, không xóa
// Format: JSONL (1 JSON object / dòng)

package ledger

import (
	"bufio"
	"encoding/json"
	"os"
	"sync"
	"time"
)

// Entry — 1 lần học
type Entry struct {
	TS         time.Time   `json:"ts"`
	Pattern    string      `json:"pattern"`    // normalized input
	Raw        string      `json:"raw"`        // input gốc
	Reply      string      `json:"reply"`      // câu trả lời
	Intent     interface{} `json:"intent"`     // ○-lang intent
	Confidence float64     `json:"confidence"`
	Learned    bool        `json:"learned"`
	Source     string      `json:"source"` // "claude" | "user" | "manual"
}

// Ledger — append-only file
type Ledger struct {
	mu    sync.Mutex
	path  string
	f     *os.File
	count int
}

func Open(path string) (*Ledger, error) {
	f, err := os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_RDWR, 0644)
	if err != nil {
		return nil, err
	}
	l := &Ledger{path: path, f: f}
	// đếm entries hiện có
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		if len(sc.Bytes()) > 2 {
			l.count++
		}
	}
	return l, nil
}

func (l *Ledger) Close() error {
	l.mu.Lock()
	defer l.mu.Unlock()
	return l.f.Close()
}

// Append — ghi 1 entry mới (append-only, không bao giờ xóa)
func (l *Ledger) Append(e *Entry) error {
	l.mu.Lock()
	defer l.mu.Unlock()
	b, err := json.Marshal(e)
	if err != nil {
		return err
	}
	b = append(b, '\n')
	_, err = l.f.Write(b)
	if err == nil {
		l.count++
	}
	return err
}

// Recent — đọc N entries gần nhất
func (l *Ledger) Recent(n int) ([]*Entry, error) {
	l.mu.Lock()
	defer l.mu.Unlock()

	f, err := os.Open(l.path)
	if err != nil {
		return nil, err
	}
	defer f.Close()

	var all []*Entry
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 1024*1024), 1024*1024)
	for sc.Scan() {
		line := sc.Bytes()
		if len(line) < 2 {
			continue
		}
		var e Entry
		if err := json.Unmarshal(line, &e); err == nil {
			all = append(all, &e)
		}
	}
	if len(all) > n {
		all = all[len(all)-n:]
	}
	return all, nil
}

func (l *Ledger) Count() int {
	l.mu.Lock()
	defer l.mu.Unlock()
	return l.count
}
