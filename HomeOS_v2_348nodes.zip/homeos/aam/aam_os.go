package aam

import "os"

func mkdirAllImpl(path string) error {
	return os.MkdirAll(path, 0755)
}

func fileExists(path string) bool {
	_, err := os.Stat(path)
	return err == nil
}

func writeFile(path string, data []byte) error {
	return os.WriteFile(path, data, 0644)
}
