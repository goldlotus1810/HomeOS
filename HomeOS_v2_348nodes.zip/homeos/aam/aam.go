// Package aam — Agent AI Master
//
// Pipeline:
//   1. matchKnowledge  — ledger cache (đã học trước đó)
//   2. queryWorldtree  — ○ KAgent TRƯỚC Claude (tiết kiệm API call)
//   3. askClaude       — nếu không tìm được trong ○
//   4. learnToWorldtree — khi Claude trả lời mới → tạo ○ node
//   5. learnToLedger   — ghi vào ledger để cache lần sau

package aam

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"

	"github.com/goldlotus1810/HomeOS/ledger"
	"github.com/goldlotus1810/HomeOS/worldtree/tools"
)

// ── Config / Response ─────────────────────────────────

type Config struct {
	ClaudeAPIKey string
	Ledger       *ledger.Ledger
	AskThreshold float64
	WorldtreeDir string
}

type Intent struct {
	Verb    string `json:"verb"`
	Chief   string `json:"chief"`
	Agent   string `json:"agent"`
	Target  string `json:"target"`
	Value   any    `json:"value"`
	Unit    string `json:"unit"`
	Symbols string `json:"symbols"`
}

type Response struct {
	Reply       string  `json:"reply"`
	Intent      *Intent `json:"intent,omitempty"`
	Confidence  float64 `json:"confidence"`
	AskedClaude bool    `json:"asked_claude"`
	Learned     bool    `json:"learned"`
	FromLedger  bool    `json:"from_ledger"`
	FromWorldtree bool  `json:"from_worldtree"`
}

// ── AAM ───────────────────────────────────────────────

type AAM struct {
	cfg       Config
	history   []claudeMsg
	knowledge map[string]*ledger.Entry
	kagent    *tools.KAgent
}

func New(cfg Config) *AAM {
	a := &AAM{
		cfg:       cfg,
		knowledge: make(map[string]*ledger.Entry),
	}
	if cfg.Ledger != nil {
		entries, _ := cfg.Ledger.Recent(500)
		for _, e := range entries {
			if e.Learned && e.Pattern != "" {
				a.knowledge[e.Pattern] = e
			}
		}
	}
	if cfg.WorldtreeDir != "" {
		if ka, err := tools.NewKAgent(cfg.WorldtreeDir); err == nil {
			a.kagent = ka
		}
	}
	return a
}

// ── Process ───────────────────────────────────────────

func (a *AAM) Process(ctx context.Context, text, session string) (*Response, error) {
	text = strings.TrimSpace(text)
	if text == "" {
		return &Response{Reply: "?"}, nil
	}

	// 1. Ledger cache
	if entry := a.matchKnowledge(text); entry != nil {
		return &Response{
			Reply:      entry.Reply,
			Intent:     entry.Intent,
			Confidence: entry.Confidence,
			FromLedger: true,
		}, nil
	}

	// 2. Check ○ WORLDTREE trước Claude
	if a.kagent != nil {
		if reply, ok := a.queryWorldtree(text); ok {
			return &Response{
				Reply:         reply,
				Confidence:    0.88,
				FromWorldtree: true,
			}, nil
		}
	}

	// 3. Hỏi Claude
	resp, err := a.askClaude(ctx, text)
	if err != nil {
		return &Response{
			Reply:      "Xin lỗi, tôi chưa xử lý được yêu cầu này.",
			Confidence: 0,
		}, nil
	}

	// 4. Học — ghi vào ledger + tạo ○ node mới
	learned := false
	if resp.Confidence >= a.cfg.AskThreshold {
		// 4a. Ledger
		if a.cfg.Ledger != nil {
			pattern := normalizePattern(text)
			entry := &ledger.Entry{
				TS:         time.Now(),
				Pattern:    pattern,
				Raw:        text,
				Reply:      resp.Reply,
				Intent:     resp.Intent,
				Confidence: resp.Confidence,
				Learned:    true,
				Source:     "claude",
			}
			if err := a.cfg.Ledger.Append(entry); err == nil {
				a.knowledge[pattern] = entry
				learned = true
			}
		}
		// 4b. ○ node — nếu là câu hỏi về concept
		if a.kagent != nil && isConceptQuery(text) {
			a.learnToWorldtree(text, resp)
		}
	}

	resp.AskedClaude = true
	resp.Learned = learned
	return resp, nil
}

// ── queryWorldtree ────────────────────────────────────

// queryWorldtree — check ○ nodes trước khi hỏi Claude
func (a *AAM) queryWorldtree(text string) (string, bool) {
	t := strings.ToLower(strings.TrimSpace(text))

	// Detect knowledge query
	knowVerbs := []string{
		"là gì", "là gì?", "giải thích", "explain",
		"what is", "what are", "define", "definition",
		"khác nhau", "difference", "so sánh", "compare",
		"khi nào dùng", "when to use", "tại sao", "why use",
		"how does", "hoạt động như thế nào",
		"ví dụ", "example",
		"nguy hiểm", "danger", "unsafe", "warning",
	}
	isKnowQuery := false
	for _, v := range knowVerbs {
		if strings.Contains(t, v) {
			isKnowQuery = true
			break
		}
	}

	// Ngắn + không có verb → có thể là tên concept trực tiếp
	if !isKnowQuery && len(strings.Fields(t)) <= 3 {
		if n, ok := a.kagent.Execute(tools.KIntent{Verb: "KNOW", Query: text, Limit: 1}).Nodes, true; ok && len(n) > 0 {
			top := n[0]
			if strings.EqualFold(top.Name, strings.TrimSpace(text)) {
				isKnowQuery = true
			}
		}
	}

	if !isKnowQuery {
		return "", false
	}

	// SEARCH trong ○
	r := a.kagent.Execute(tools.KIntent{
		Verb:  "SEARCH",
		Query: text,
		Limit: 3,
	})
	if !r.OK || len(r.Nodes) == 0 {
		return "", false
	}

	top := r.Nodes[0]
	topLower := strings.ToLower(top.Name)

	// Kiểm tra top result có liên quan đến query không
	words := strings.Fields(t)
	matched := false
	for _, w := range words {
		if len(w) < 3 {
			continue
		}
		if strings.Contains(topLower, w) || strings.Contains(t, topLower) {
			matched = true
			break
		}
	}
	if !matched {
		return "", false
	}

	// Format reply
	var sb strings.Builder
	sym := top.Sym
	if sym == "" {
		sym = "○"
	}
	sb.WriteString(fmt.Sprintf("%s  **%s**\n", sym, top.Name))
	sb.WriteString(top.Summary + "\n")

	if len(top.Facts) > 0 {
		sb.WriteString("\n")
		for i, f := range top.Facts {
			if i >= 3 {
				break
			}
			fsym := f.Sym
			if fsym == "" {
				fsym = "•"
			}
			sb.WriteString(fmt.Sprintf("  %s %s\n", fsym, f.Text))
		}
	}

	if len(top.ExistsIn) > 0 {
		sb.WriteString(fmt.Sprintf("\nCó trong: %s\n", strings.Join(top.ExistsIn, ", ")))
	}
	if len(top.NotIn) > 0 {
		sb.WriteString(fmt.Sprintf("Không có trong: %s\n", strings.Join(top.NotIn, ", ")))
	}
	if len(top.Danger) > 0 {
		sb.WriteString(fmt.Sprintf("\n⚠ **Cẩn thận:** %s\n", top.Danger[0]))
	}

	// Liên quan
	if len(r.Nodes) > 1 {
		var related []string
		for _, n := range r.Nodes[1:] {
			s := n.Sym
			if s == "" {
				s = "○"
			}
			related = append(related, fmt.Sprintf("%s %s", s, n.Name))
		}
		sb.WriteString(fmt.Sprintf("\nLiên quan: %s\n", strings.Join(related, " · ")))
	}

	sb.WriteString(fmt.Sprintf("\n*(○ WORLDTREE · SDF [%.2f,%.2f,%.2f] · L%d)*",
		top.SDF[0], top.SDF[1], top.SDF[2], top.Layer))

	return sb.String(), true
}

// ── learnToWorldtree ──────────────────────────────────

// learnToWorldtree — tạo ○ node mới từ câu trả lời của Claude
func (a *AAM) learnToWorldtree(query string, resp *Response) {
	if a.kagent == nil || resp.Reply == "" {
		return
	}

	// Tạo node từ query + reply
	sdf := tools.SDFFromText(query + " " + resp.Reply)

	// Tên node từ query (lấy danh từ chính)
	name := extractNodeName(query)
	if name == "" || len(name) > 60 {
		return
	}

	// Kiểm tra đã có chưa
	if existing, ok := a.kagent.Store().Get(name); ok && existing != nil {
		return
	}

	// Build facts từ reply
	sentences := splitSentences(resp.Reply)
	var facts []struct {
		Sym  string `json:"sym"`
		Text string `json:"text"`
	}
	for i, s := range sentences {
		if i >= 5 {
			break
		}
		s = strings.TrimSpace(s)
		if len(s) < 10 {
			continue
		}
		facts = append(facts, struct {
			Sym  string `json:"sym"`
			Text string `json:"text"`
		}{Sym: "→", Text: s})
	}
	if len(facts) == 0 {
		return
	}

	// Summary = câu đầu tiên của reply
	summary := resp.Reply
	if idx := strings.Index(summary, "\n"); idx > 0 {
		summary = summary[:idx]
	}
	if len(summary) > 200 {
		summary = summary[:200] + "…"
	}

	node := &tools.KNode{
		Name:       name,
		Sym:        "○",
		Symbol:     "○",
		Layer:      7, // learned
		Category:   "learned",
		SDF:        sdf,
		ISL:        [4]int{7, 0, 0, 0},
		Summary:    summary,
		Tags:       extractTags(query),
		Related:    []string{},
		ExistsIn:   []string{},
		NotIn:      []string{},
		Danger:     []string{},
		Source:     "claude_learned",
	}
	// Gán facts (type hack vì KNode.Facts là anonymous struct)
	// Dùng AddLearnedNode để thêm vào RAM store
	a.kagent.Store().AddLearnedNode(node)

	// Ghi file vào disk (WORLDTREE/learned/prog/)
	if a.cfg.WorldtreeDir != "" {
		a.writeLearnedNode(node, resp.Reply)
	}
}

// writeLearnedNode — ghi file ○node.json vào disk
func (a *AAM) writeLearnedNode(node *tools.KNode, fullReply string) {
	learnedDir := a.cfg.WorldtreeDir + "/learned/prog"
	// Tạo thư mục nếu chưa có
	if err := mkdirAll(learnedDir); err != nil {
		return
	}

	safeName := safePath(node.Name)
	if safeName == "" {
		return
	}
	fpath := learnedDir + "/" + safeName + ".○node.json"

	// Không ghi đè node có sẵn
	if fileExists(fpath) {
		return
	}

	// Build full node JSON
	type factItem struct {
		Sym  string `json:"sym"`
		Text string `json:"text"`
	}
	sentences := splitSentences(fullReply)
	var facts []factItem
	for i, s := range sentences {
		if i >= 5 {
			break
		}
		s = strings.TrimSpace(s)
		if len(s) < 10 {
			continue
		}
		facts = append(facts, factItem{Sym: "→", Text: s})
	}

	type nodeJSON struct {
		ID         string      `json:"id"`
		Name       string      `json:"name"`
		Symbol     string      `json:"symbol"`
		Sym        string      `json:"sym"`
		Layer      int         `json:"layer"`
		Category   string      `json:"category"`
		SDF        [3]float64  `json:"sdf"`
		ISL        [4]int      `json:"isl"`
		Summary    string      `json:"summary"`
		Facts      []factItem  `json:"facts"`
		Tags       []string    `json:"tags"`
		Related    []string    `json:"related"`
		ExistsIn   []string    `json:"exists_in"`
		NotIn      []string    `json:"not_in"`
		NOTIn      []string    `json:"NOT_in"`
		Danger     []string    `json:"danger"`
		Confidence float64     `json:"confidence"`
		Source     string      `json:"source"`
	}

	nj := nodeJSON{
		ID:         safeName,
		Name:       node.Name,
		Symbol:     "○",
		Sym:        "○",
		Layer:      7,
		Category:   "learned",
		SDF:        node.SDF,
		ISL:        [4]int{7, 0, 0, 0},
		Summary:    node.Summary,
		Facts:      facts,
		Tags:       node.Tags,
		Related:    []string{},
		ExistsIn:   []string{},
		NotIn:      []string{},
		NOTIn:      []string{},
		Danger:     []string{},
		Confidence: 0.75,
		Source:     "claude_learned_" + time.Now().Format("20060102"),
	}

	data, err := json.MarshalIndent(nj, "", "  ")
	if err != nil {
		return
	}
	writeFile(fpath, data)
}

// ── Claude API ────────────────────────────────────────

type claudeMsg struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

type claudeReq struct {
	Model     string      `json:"model"`
	MaxTokens int         `json:"max_tokens"`
	System    string      `json:"system"`
	Messages  []claudeMsg `json:"messages"`
}

type claudeResp struct {
	Content []struct {
		Type string `json:"type"`
		Text string `json:"text"`
	} `json:"content"`
	Error *struct {
		Message string `json:"message"`
	} `json:"error"`
}

func (a *AAM) askClaude(ctx context.Context, text string) (*Response, error) {
	if a.cfg.ClaudeAPIKey == "" {
		return a.fallback(text), nil
	}

	a.history = append(a.history, claudeMsg{Role: "user", Content: text})
	if len(a.history) > 20 {
		a.history = a.history[len(a.history)-20:]
	}

	reqBody, _ := json.Marshal(claudeReq{
		Model:     "claude-sonnet-4-20250514",
		MaxTokens: 800,
		System:    systemPrompt,
		Messages:  a.history,
	})

	req, err := http.NewRequestWithContext(ctx, "POST",
		"https://api.anthropic.com/v1/messages",
		bytes.NewReader(reqBody))
	if err != nil {
		return nil, err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("x-api-key", a.cfg.ClaudeAPIKey)
	req.Header.Set("anthropic-version", "2023-06-01")

	httpResp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("claude api: %w", err)
	}
	defer httpResp.Body.Close()

	body, _ := io.ReadAll(httpResp.Body)
	var cr claudeResp
	if err := json.Unmarshal(body, &cr); err != nil {
		return nil, fmt.Errorf("claude parse: %w", err)
	}
	if cr.Error != nil {
		return nil, fmt.Errorf("claude: %s", cr.Error.Message)
	}

	raw := ""
	for _, c := range cr.Content {
		if c.Type == "text" {
			raw += c.Text
		}
	}
	raw = strings.TrimSpace(raw)
	raw = strings.TrimPrefix(raw, "```json")
	raw = strings.TrimPrefix(raw, "```")
	raw = strings.TrimSuffix(raw, "```")
	raw = strings.TrimSpace(raw)

	a.history = append(a.history, claudeMsg{Role: "assistant", Content: raw})

	var parsed struct {
		Reply      string  `json:"reply"`
		Intent     *Intent `json:"intent"`
		Confidence float64 `json:"confidence"`
	}
	if err := json.Unmarshal([]byte(raw), &parsed); err != nil {
		return &Response{Reply: raw, Confidence: 0.3}, nil
	}

	return &Response{
		Reply:      parsed.Reply,
		Intent:     parsed.Intent,
		Confidence: parsed.Confidence,
	}, nil
}

// fallback — không có API key
func (a *AAM) fallback(text string) *Response {
	t := strings.ToLower(text)
	switch {
	case strings.Contains(t, "đèn") && (strings.Contains(t, "bật") || strings.Contains(t, "mở")):
		return &Response{
			Reply:  "Đang bật đèn...",
			Intent: &Intent{Verb: "ON", Chief: "HomeChief", Agent: "LightAgent", Target: "all", Symbols: "💡⧺ON"},
			Confidence: 0.9,
		}
	case strings.Contains(t, "đèn") && strings.Contains(t, "tắt"):
		return &Response{
			Reply:  "Đã tắt đèn.",
			Intent: &Intent{Verb: "OFF", Chief: "HomeChief", Agent: "LightAgent", Target: "all", Symbols: "💡⧺OFF"},
			Confidence: 0.9,
		}
	case strings.Contains(t, "điều hòa") || strings.Contains(t, "nhiệt độ"):
		return &Response{
			Reply:  "Nhiệt độ hiện tại: 26°C.",
			Intent: &Intent{Verb: "GET", Chief: "HomeChief", Agent: "HVACAgent", Symbols: "🌡⧺GET"},
			Confidence: 0.85,
		}
	case strings.Contains(t, "khóa") || strings.Contains(t, "lock"):
		return &Response{
			Reply:  "Đã khóa cửa.",
			Intent: &Intent{Verb: "LOCK", Chief: "HomeChief", Agent: "LockAgent", Target: "front_door", Symbols: "🔒⧺LOCK"},
			Confidence: 0.9,
		}
	default:
		return &Response{
			Reply:      "Tôi chưa hiểu yêu cầu này. (ANTHROPIC_API_KEY chưa được set)",
			Confidence: 0.1,
		}
	}
}

// ── Knowledge matching ────────────────────────────────

func (a *AAM) matchKnowledge(text string) *ledger.Entry {
	pattern := normalizePattern(text)
	if e, ok := a.knowledge[pattern]; ok {
		return e
	}
	for p, e := range a.knowledge {
		if strings.Contains(pattern, p) || strings.Contains(p, pattern) {
			if e.Confidence >= 0.8 {
				return e
			}
		}
	}
	return nil
}

func normalizePattern(text string) string {
	t := strings.ToLower(strings.TrimSpace(text))
	r := strings.NewReplacer("?", "", "!", "", ",", "", ".", "", " ơi", "", "homeos", "", "  ", " ")
	return strings.TrimSpace(r.Replace(t))
}

// ── Helpers ───────────────────────────────────────────

func isConceptQuery(text string) bool {
	t := strings.ToLower(text)
	triggers := []string{
		"là gì", "what is", "explain", "giải thích",
		"define", "khác nhau", "difference", "so sánh",
	}
	for _, tr := range triggers {
		if strings.Contains(t, tr) {
			return true
		}
	}
	return false
}

func extractNodeName(query string) string {
	t := strings.ToLower(strings.TrimSpace(query))
	// Bỏ các từ query
	removes := []string{
		"là gì", "what is", "giải thích", "explain", "define",
		"?", "!", ".", ",", " ơi", "homeos",
		"khác nhau", "difference between", "so sánh", "compare",
		"khi nào dùng", "when to use",
	}
	for _, r := range removes {
		t = strings.ReplaceAll(t, r, "")
	}
	t = strings.TrimSpace(t)
	if len(t) < 2 || len(t) > 60 {
		return ""
	}
	// Title case
	words := strings.Fields(t)
	if len(words) == 0 {
		return ""
	}
	return strings.Join(words, "-")
}

func extractTags(text string) []string {
	words := strings.Fields(strings.ToLower(text))
	var tags []string
	stop := map[string]bool{
		"là": true, "gì": true, "the": true, "a": true, "an": true,
		"is": true, "what": true, "how": true, "why": true,
		"và": true, "or": true, "in": true, "of": true,
	}
	for _, w := range words {
		w = strings.Trim(w, "?!.,")
		if len(w) >= 3 && !stop[w] {
			tags = append(tags, w)
		}
		if len(tags) >= 5 {
			break
		}
	}
	return tags
}

func splitSentences(text string) []string {
	var sentences []string
	for _, s := range strings.Split(text, "\n") {
		s = strings.TrimSpace(s)
		if s != "" {
			sentences = append(sentences, s)
		}
	}
	if len(sentences) <= 1 {
		sentences = strings.Split(text, ". ")
	}
	return sentences
}

func safePath(s string) string {
	var b strings.Builder
	for _, r := range strings.ToLower(s) {
		if (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') || r == '-' || r == '_' {
			b.WriteRune(r)
		} else if r == ' ' {
			b.WriteRune('-')
		}
	}
	result := b.String()
	if len(result) > 64 {
		result = result[:64]
	}
	return result
}

func mkdirAll(path string) error {
	return mkdirAllImpl(path)
}

// implemented via os package — xem aam_os.go
