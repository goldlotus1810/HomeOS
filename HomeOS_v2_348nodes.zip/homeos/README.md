# HomeOS v2 — ○ WORLDTREE

AI-powered home automation với knowledge graph tự học.

## Kiến trúc

```
Người dùng
    │
    ▼
AAM (Agent AI Master)
├── 1. Check Ledger (cache)
├── 2. Check ○ WORLDTREE (KAgent) ← TRƯỚC Claude
├── 3. Ask Claude (nếu cần)
├── 4. Learn → ○ node mới
└── 5. Learn → Ledger
    │
    ├── HomeChief   → LightAgent, HVACAgent, LockAgent
    ├── EnergyChief → BatteryAgent
    ├── VisionChief → CameraAgent
    ├── SystemChief → SystemAgent
    ├── WebChief    → WebAgent (học từ URL)
    └── KnowledgeChief → KnowledgeAgent (○ query)
```

## Cài đặt

```bash
# Yêu cầu: Go 1.22+
git clone https://github.com/goldlotus1810/HomeOS
cd HomeOS
export ANTHROPIC_API_KEY=sk-ant-...
go run .
# → http://localhost:8080
```

## Biến môi trường

| Biến | Mặc định | Mô tả |
|------|----------|-------|
| `ANTHROPIC_API_KEY` | — | Claude API key |
| `HOMEOS_PORT` | `8080` | HTTP port |
| `HOMEOS_WORLDTREE` | `WORLDTREE` | Thư mục ○ nodes |
| `HOMEOS_LEDGER` | `ledger.jsonl` | Ledger file |

## API Endpoints

| Endpoint | Method | Mô tả |
|----------|--------|-------|
| `POST /api/chat` | POST | Chat với AAM |
| `GET /api/knowledge?verb=SEARCH&q=rust` | GET | Query ○ WORLDTREE |
| `GET /api/health` | GET | Status + node count |
| `GET /api/ledger` | GET | 50 entries gần nhất |
| `GET /api/agents` | GET | Agent status |

### /api/knowledge verbs

- `KNOW` — tìm chính xác theo tên
- `SEARCH` — full-text search
- `NEAR` — tìm node gần nhất theo SDF
- `LANG` — tất cả concepts của ngôn ngữ
- `RELATE` — graph traversal
- `UNION` — smooth union nhiều queries
- `STATS` — thống kê kho
- `DANGER` — nodes có warning nguy hiểm

## ○ WORLDTREE

```
WORLDTREE/
  learned/
    prog/
      MANIFEST.json       ← index tự động
      *.○node.json        ← knowledge nodes (human-readable)
      *.○node.slk         ← SILK binary (ISL format)
```

**141 nodes** — L1-L7:
- L1: Primitives (bit, byte, int, float, pointer, string...)
- L2: Operations (add, bitwise, load, store, call...)
- L3: Constructs (if-else, for, ownership, goroutine, async...)
- L4: Paradigms (functional, OOP, concurrent, CSP, actor...)
- L5: Languages (Go, Rust, Python, JS, Java, C, Haskell...)
- L6: Algorithms & Patterns (quicksort, DP, hashmap, SOLID...)
- L7: Engineering Skills (TDD, DRY, debugging, CI-CD...)

**Related refs**: 461/699 resolved (66%)

## ISL Address Format

```
64-bit: [Layer 1B][Group 1B][Type 1B][ID 1B][Attributes 4B]
```

## SDF Space

```
x: -1=hardware/assembly  →  +1=high-level/declarative
y: -1=unsafe/manual      →  +1=safe/managed
z: -1=imperative/stateful →  +1=functional/pure
```

## Quy tắc bất biến

- WORLDTREE: chỉ thêm, không xóa, không đổi tên
- Ledger: append-only (QT7: học)
- Agents: AAM ↔ Chief ↔ Agent (không bỏ qua tầng)
